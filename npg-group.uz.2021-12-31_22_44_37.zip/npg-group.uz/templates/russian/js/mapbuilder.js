/* global jvm, Modernizr */
'use strict';

(function( $, window ) {

	var pluginName = 'mapBuilder',
	    defaults   = {
		    getMapData:       null,
		    getCountryValues: null
	    };

	function Plugin( element, options ) {
		var plugin = this;

		plugin.$element  = $( element );
		plugin._defaults = defaults;
		plugin._name     = pluginName;
		plugin.options   = $.extend( {}, defaults, options );

		plugin.map         = {};
		plugin.vMapWrapper = plugin.$element.parents( '.map-wrapper' );
		plugin.form        = plugin.vMapWrapper.closest( 'form' );

		plugin.countryData = {};
		plugin.mapIcons    = {};
		plugin.mapData     = {};
		plugin.mapRegions  = {};

		plugin.btnResetMap  = plugin.vMapWrapper.find( '.js_button-show-prev-map' );
		plugin.btnToggleMap = plugin.vMapWrapper.find( '.js_button-toggle-map' );


		plugin.legend       = {};
		plugin.$popup       = plugin.vMapWrapper.find( '.js_vector-map-popup' );
		plugin.cityMarkers  = [];
		plugin.actualRegion = '';

		plugin.regionInitialColor  = '#e2e3e4';
		plugin.regionHoverColor    = '#e60041';
		plugin.regionSelectedColor = '#e60041';

		plugin.initialMapSettings = {
			container:        '',
			map:              'world_mill',
			mapSrc:           'http://man-centre.com/templates/russian/js/world_mill_en.js',
			mapType:          '',
			focusOn:          {
				x:       0,
				y:       0,
				scale:   0,
				animate: false
			},
			customFocus:      false,
			markers:          plugin.cityMarkers.map( function( h ) {
				return {name: h.name, latLng: h.latLng};
			} ),
			labels:           {
				markers: {
					//set city name at marker
					render:  function( index ) {
						return plugin.cityMarkers[index].name;
					},
					// shift city name to left/right (offset[0]) or top/bottom (offset[1])
					offsets: function( index ) {
						var position = plugin.cityMarkers[index].position;
						switch (position) {
							case 'top':
								return [0, -8];
								break;
							case 'bottom':
								return [0, 8];
								break;
							default:
								return [0, 0];
						}
					}
				}
			},
			backgroundColor:  'transparent',
			regionStyle:      {
				initial:  {
					fill:           plugin.regionInitialColor,
					'fill-opacity': 1,
					cursor:         'auto'
				},
				hover:    {
					'fill-opacity': 1,
					cursor:         'auto'
				},
				selected: {
					fill:           plugin.regionSelectedColor,
					'fill-opacity': 1
				}
			},
			regionLabelStyle: {
				initial: {
					fill:           '#B90E32',
					'fill-opacity': 1
				},
				hover:   {
					fill: 'black'
				}
			},
			markerStyle:      {
				initial: {
					'fill-opacity': 1,
					fill:           '#303c49'
				}
			},
			markerLabelStyle: {
				initial: {
					'font-size':    '14',
					cursor:         'default',
					fill:           '#303C49',
					stroke:         '#838A92',
					'stroke-width': '0.5'
				}
			},
			series:           {
				regions: [{
					scale:      {
						'production':  '#303C49',
						'cooperation': '#ACB1B6',
						'basic':       '#303C49'
					},
					values:     {},
					scrollable: false,
					attribute:  'fill'
				}],
				markers: []
			},

			regionsSelectable: true,
			onRegionClick:     function( evt, code ) {
				plugin.onRegionClick( evt, code, plugin );
			},
			onRegionOver:      function( evt, code ) {
				plugin.onRegionOver( evt, code, plugin );
			},
			onRegionTipShow:   function( evt, tip, code ) {
				plugin.onRegionTipShow( evt, tip, code, plugin );
			},
			onMarkerClick:     function( evt, code ) {
				plugin.onMarkerClick( evt, code, plugin );
			},
			onMarkerTipShow:   function( evt, tip, code ) {
				plugin.onMarkerTipShow( evt, tip, code, plugin );
			}
		};

		// copy settings for second map
		plugin.swapMapSettings = plugin.initialMapSettings;

		this.init();
	}

	$.extend( Plugin.prototype, {

		init:                 function() {
			// set mapType (currently only 'region-map' in use)
			if (typeof this.options.mapType !== 'undefined') {
				this.initialMapSettings.mapType = this.options.mapType;
			}

			if (typeof this.options.values !== 'undefined') {
				// region values for region-map
				this.setRegions( this.options.values );
				this.getInitialMapOptions();
			} else {
				// get region data for other than region-map
				this.countryData = this.getMapData();

				if (typeof this.countryData.done === 'function') { // data retrieved via AJAX, so we get a Deferred object
					var me = this;
					this.countryData.done( function( responseData ) {
						if (responseData && typeof responseData === 'object') {
							me.setRegions( responseData );
							me.getInitialMapOptions();
						}
					} );
				}

				this.mapIcons = this.getMapIcons();
				if (typeof this.mapIcons.done === 'function') { // data retrieved via AJAX, so we get a Deferred object
					this.mapIcons.done( function( responseData ) {
						if (responseData && typeof responseData === 'object') {
							this.setMarkerIcons( responseData );
						}
					} );
				}
			}

			// set legend data
			if (typeof this.options.mapSettings !== 'undefined') {
				this.initialMapSettings.series.regions = this.options.mapSettings.series.regions;
				this.swapMapSettings.series.regions    = this.options.mapSettings.series.regions;
			}


			this.clickHandler();

		},
		getInitialMapOptions: function() {
			this.initialMapSettings.container = this.$element;
			this.swapMapSettings.container    = this.$element;

			// hide click prompt for mobile devices
			if (Modernizr.touch) {
				$( 'figcaption.link.icon-map-cursor' ).hide();
			}

			// check if region or continent/world should be loaded
			var mapIndicator = this.$element.data( 'region' );

			if (typeof this.mapData[mapIndicator.toUpperCase()] !== 'undefined') {
				// => map = map of specific region
				mapIndicator                = mapIndicator.toUpperCase();
				this.initialMapSettings.map = this.mapData[mapIndicator].mapId + '_mill';

				if (mapIndicator === 'ru') {
					// hide "back-to-prev-map"-button
					this.vMapWrapper.addClass( 'state_region_only' );
				}

			} else {
				// => map = world / continent map
				this.initialMapSettings.map = mapIndicator + '_mill';
			}

			this.buildInitialMap( mapIndicator );
			// set initial zoom for map
			this.setFocus( this.initialMapSettings );

		},
		getMapData:           function() {

			if (this.options.getMapData) {
				return this.options.getMapData( this.$element );
			}
			var uriData = this.$element.data( 'uri-countrydata' ) || null;

			if (!uriData) {
				throw new Error( 'jquery.vectorMapFactory: You must specify an attribute data-uri-countrydata for the element on which you apply the jVectorMap plugin.' );
			}
			return $.ajax( {
				'url':      uriData,
				'type':     'GET',
				'dataType': 'json',
				context:    this
			} );

		},
		getMapIcons:          function() {
			var iconData = this.$element.data( 'icondata' ) || null;

			if (!iconData) {
				throw new Error( 'jquery.vectorMapFactory: You must specify an attribute data-icondata for the element on which you apply the jVectorMap plugin.' );
			}
			return $.ajax( {
				'url':      iconData,
				'type':     'GET',
				'dataType': 'json',
				context:    this
			} );
		},
		setMarkerIcons:       function( icons ) {
			this.initialMapSettings.series.markers = [{attribute: 'image', scale: icons}];
			this.swapMapSettings.series.markers    = [{attribute: 'image', scale: icons}];
		},
		setRegions:           function( countryData ) {

			// get each region type for different color highlighting
			for (var usedCountryCode in countryData) {

				if (typeof usedCountryCode !== 'undefined' && countryData[usedCountryCode].hasOwnProperty( 'type' ) && typeof countryData[usedCountryCode].type !== 'undefined') {
					this.mapRegions[usedCountryCode] = countryData[usedCountryCode].type;
				} else if (typeof usedCountryCode !== 'undefined') {
					this.mapRegions[usedCountryCode] = 'basic';
				}
			}

			// set regions for being correctly highlighted
			this.initialMapSettings.series.regions[0].values = this.mapRegions;
			this.mapData                                     = countryData;

		},
		buildInitialMap:      function( mapIndicator ) {

			this.buildMap( this.initialMapSettings, mapIndicator );
			this.setLegendText();

		},

		buildMap:                        function( settings, region ) {
			var me = this;
			region = (region.length > 2) ? region : region.toUpperCase();

			var mapIdentifier = typeof me.mapData[region] === 'undefined' ? region : me.mapData[region].mapId;

			mapIdentifier = mapIdentifier + '_mill';
			var mapSrc    = '';
			var mapName   = mapIdentifier;

			switch (mapIdentifier) {
				case 'ru_mill':
					mapSrc = 'http://www.truck.man.eu/ru/media/nresources/nscripts/async/maps/ru_mill.js';
					break;
				case 'europe_mill':
					mapSrc = 'http://www.truck.man.eu/ru/media/nresources/nscripts/async/maps/europe_mill.js';
					break;
				case 'asia_mill':
					mapSrc = 'http://www.truck.man.eu/ru/media/nresources/nscripts/async/maps/asia_mill.js';
					break;
				case 'north_america_mill':
					mapSrc = 'http://www.truck.man.eu/ru/media/nresources/nscripts/async/maps/north_america_mill.js';
					break;
				case 'south_america_mill':
					mapSrc = 'http://www.truck.man.eu/ru/media/nresources/nscripts/async/maps/south_america_mill.js';
					break;
				case 'africa_mill':
					mapSrc = 'http://www.truck.man.eu/ru/media/nresources/nscripts/async/maps/africa_mill.js';
					break;
				case 'oceania_mill':
					mapSrc = 'http://www.truck.man.eu/ru/media/nresources/nscripts/async/maps/oceania_mill.js';
					break;
				default:
					mapName = 'world_mill';
					mapSrc  = 'http://www.truck.man.eu/ru/media/nresources/nscripts/async/maps/world_mill_en.js';
					break;
			}
			me.getMapScript( settings, mapName, mapSrc, region );
		},
		getMapScript:                    function( settings, mapName, mapSrc, region ) {
			var me = this;

			$.getScript( mapSrc ).done( function() {

				if (!$.isEmptyObject( me.map )) {
					me.map.remove();
				}

				me.extendMapSettings( mapName, settings, mapSrc );

				// timeout for displaying map in cms -> loading issues when included in official site
				setTimeout( function(  ) {
					me.map = new jvm.Map( settings );

					me.setLegendText();
					me.addFastClickBugFixToSvgElements();
					me.addRegionMarker( region );
					me.addBahrain();

					// display back-to-prev-map-button; zoom in
					if (mapName !== 'ru_mill' && typeof me.mapData[region] !== 'undefined') {
						me.vMapWrapper.removeClass( 'state_ru' );
						me.vMapWrapper.addClass( 'state_back_to_continent' );

						// if no focus was given per data-attrs then zoom to clicked region
						if (!settings.customFocus) {
							me.map.setFocus( {
								region:  region,
								animate: !me.vMapWrapper.hasClass( 'state_back_to_continent' )
							} );
						}
						// set color of selected region
						me.map.setSelectedRegions( region );
					}
				}, 50 );


			} );

		},
		extendMapSettings:               function( mapName, settings, mapSrc ) {
			if (mapName === 'ru_mill') {
				// set all regions of russland map red
				settings.regionStyle.initial.fill = this.regionSelectedColor;
				settings.regionsSelectable        = false;
				this.vMapWrapper.addClass( 'state_ru' );
			} else {
				settings.regionStyle.initial.fill = this.regionInitialColor;
			}
			settings.map    = mapName;
			settings.mapSrc = mapSrc;
		},
		setFocus:                        function( settings ) {
			// set initial zoom for map
			var data               = this.$element.data();
			settings.focusOn.x     = ( typeof data.focusX !== 'undefined' && data.focusX !== '' ) ? data.focusX : 0;
			settings.focusOn.y     = ( typeof data.focusY !== 'undefined' && data.focusY !== '' ) ? data.focusY : 0;
			settings.focusOn.scale = ( typeof data.focusScale !== 'undefined' && data.focusScale !== '' ) ? data.focusScale : 0;

			settings.customFocus = (settings.focusOn.x !== 0 && settings.focusOn.y !== 0 && settings.focusOn.scale !== 0 );
		},
		resetFocus:                      function( settings ) {
			settings.focusOn.x     = 0;
			settings.focusOn.y     = 0;
			settings.focusOn.scale = 0;
			settings.customFocus   = false;
		},
		addBahrain:                      function() {
			if (this.initialMapSettings.mapType === 'map-router') {
				// add Bahrain
				this.cityMarkers = {'BH': {latLng: [26.02, 50.55], name: 'Bahrain'}};
				this.map.addMarkers( this.cityMarkers );

				this.addFastClickBugfixToMarker();

			}
		},
		onRegionClick:                   function( evt, code, plugin ) {
			var me = plugin;

			// disable click event for actual selected region
			// necessary if initial data-region is not a continent / not world
			if (me.actualRegion === code) {
				evt.preventDefault();
				return;
			}

			// check if selected region is in mapData
			if (me.mapData[code]) {

				// check if map is map-router
				var actLinks = me.mapData[code].links;
				if (typeof actLinks !== 'undefined') {
					me.handleMapRouterPopup( me.mapData[code], actLinks );
				} else {
					me.resetFocus( me.swapMapSettings );
					// build map of selected region
					me.map.clearSelectedRegions();
					me.buildMap( me.swapMapSettings, code );
					// show back-to-prev-map button
					me.vMapWrapper.addClass( 'state_back_to_continent' );
				}

			} else {
				// set region color for regions not in json
				me.map.series.regions[0].elements[code].element.config.style.selected.fill = me.regionInitialColor;
			}

		},
		handleMapRouterPopup:            function( region, actLinks ) {
			// create popup for map router map
			var labelData   = $( '#js_tpl-header-autocomplete' ).data( 'link-text' );
			var $mapWrapper = this.$element.parents( '.map-wrapper' );

			var actRegion       = region;
			var popupTpl        = $mapWrapper.find( '.js_MapPopupTpl' ).text();
			var linkListItemTpl = $mapWrapper.find( '.js_mapLinkList' ).text();

			var linkListContainer = '';

			for (var linkitem in actLinks) {
				linkListContainer += linkListItemTpl
					.replace( '{{url}}', actLinks[linkitem] )
					.replace( '{{linktext}}', labelData[linkitem] );
			}

			popupTpl = popupTpl
				.replace( '{{headline}}', actRegion.curLng )
				.replace( '{{linkList}}', linkListContainer );

			// add tpl to html
			this.$popup.html( popupTpl );
			this.$popup.show();
		},
		addRegionMarker:                 function( code ) {
			var me = this;

			if (typeof me.mapData[code] !== 'undefined' && typeof me.mapData[code].mapId !== 'undefined') {


				if (typeof this.countryData.done === 'function') { // data retrieved via AJAX, so we get a Deferred object
					this.countryData.done( function( responseData ) {
						if (responseData && typeof responseData === 'object') {
							// get cities of selected region
							me.cityMarkers = responseData[code].markers;
						}
					} );
				}

				if (typeof me.cityMarkers !== 'undefined') {

					// get city-icon-code
					var iconValues = me.cityMarkers.reduce( function( p, c, i ) {
						p[i] = c.image;
						return p;
					}, {} );

					// add markers including icons
					me.map.addMarkers( me.cityMarkers, [iconValues] );

					me.addFastClickBugfixToMarker()
				}
				me.actualRegion = code;
			}
		},
		onRegionOver:                    function( event, code, plugin ) {
			var me   = plugin;
			var $tip = $( '.jvectormap-tip' );

			// set class so tip is available for map-router maps
			if (me.initialMapSettings.mapType === 'map-router' && me.mapData[code]) {
				$tip.addClass( 'router-tip' );
			} else {
				$tip.removeClass( 'router-tip' );
			}

			if (!me.mapData || !me.mapData[code]) {
				return false;
			}

			// hover color only if region exists in json
			if (me.mapData[code]) {
				me.map.series.regions[0].elements[code].element.config.style.hover.fill   = me.regionHoverColor;
				me.map.series.regions[0].elements[code].element.config.style.hover.cursor = 'pointer';
			}
		},
		onRegionTipShow:                 function( evt, tip, code, plugin ) {

			if (this.initialMapSettings.mapType === 'map-router' && typeof this.mapData[code] !== 'undefined' ) {
				tip.html(' ' + this.mapData[code].curLng );
			}

			// function needed for disabling hover-effect of mobile device on first tap
			// otherwise user has to tap two times
			if (Modernizr.touch) {
				this.onRegionClick( evt, code, plugin );
			}
		},
		onMarkerTipShow:                 function( evt, tip, code, plugin ) {
			// function needed for disabling hover-effect of mobile device on first tap
			// otherwise user has to tap two times
			if (Modernizr.touch) {
				this.onMarkerClick( evt, code, plugin );
			}
		},
		onMarkerClick:                   function( evt, code, plugin ) {
			var me = plugin;

			if (me.initialMapSettings.mapType === 'map-router') {
				// handle click for markers set additionally in map-router; like Bahrain
				me.handleMapRouterPopup( me.mapData[code], me.mapData[code].links );

			} else {

				// get label content of clicked marker
				var actMarkerId = me.mapData[this.actualRegion].markers[code].markerId;

				var $popupTpl = $( '#' + actMarkerId );

				// get location search parameter
				var params = $popupTpl.data();
				var link   = '';

				if (!$.isEmptyObject( params )) {
					for (var param in params) {
						if (param !== '') {
							link += (link.indexOf( '?' ) !== -1) ? '&' + param + '=' + params[param] : '?' + param + '=' + params[param];
						}
					}
					link += '&id=' + actMarkerId;
				}

				var popupTpl = $popupTpl.text();

				// add tpl to html
				me.$popup.html( popupTpl );
				// add location search parameter
				var locLink = me.$popup.find( 'a' ).attr( 'href' );
				me.$popup.find( 'a' ).attr( 'href', locLink + link );
				// show popup
				me.$popup.show();
			}

		},
		setLegendText:                   function() {

			var me = this;

			if (typeof me.options.mapSettings !== 'undefined' &&
				( typeof me.$element.data( 'lgdproduction' ) !== 'undefined' && typeof me.$element.data( 'lgdcoop' ) !== 'undefined' )) {

				// exchange label texts
				var legendText = me.vMapWrapper.find( '.jvectormap-legend-tick-text' );

				if (legendText.length) {
					legendText.eq( 0 ).html( me.$element.data( 'lgdproduction' ) );
					legendText.eq( 1 ).html( me.$element.data( 'lgdcoop' ) );
				}
			}

		},
		hidePopup:                       function() {
			if (!$.isEmptyObject( this.$popup )) {
				this.$popup.hide();
			}
		},
		clickHandler:                    function() {
			var me = this;

			// reset map to prev state
			me.btnResetMap.on( 'click', function() {
				me.hidePopup();

				// if initial map is region map -> load assigned continent
				// if data('region').length = 2 => initial map is region map
				if (me.$element.data( 'region' ).length <= 2) {
					me.resetFocus( me.swapMapSettings );

					me.buildMap( me.swapMapSettings, me.mapData[me.$element.data( 'region' ).toUpperCase()].mapId );

				} else {
					me.setFocus( me.initialMapSettings );
					// else if initial map is world or continent -> load it again
					me.buildInitialMap( me.$element.data( 'region' ) );
				}

				me.actualRegion = '';

				me.vMapWrapper.removeClass( 'state_ru' );
				me.vMapWrapper.removeClass( 'state_back_to_continent' );
				me.vMapWrapper.removeClass( 'state_selected' );

			} );

			me.btnToggleMap.on( 'click', function() {
				me.vMapWrapper.removeClass( 'state_selected' );
			} );

			me.vMapWrapper.on( 'click', '.js_close', function( e ) {
				e.preventDefault();
				me.hidePopup();
				if (me.initialMapSettings.mapType === 'map-router') {
					me.map.clearSelectedRegions();
				}

			} ).on( 'click', '.js_vector-map-popup a:not(".nofold")', function( e ) {

				// animate map height and load new page if not map-router map
				//if (me.initialMapSettings.mapType !== 'map-router' ) {
				if ($( this ).closest( '#routerMap' ).length === 0) {
					e.preventDefault();
					var url = $( this ).attr( 'href' );
					me.vMapWrapper.addClass( 'state_selected' );
					setTimeout( function() {
						me.hidePopup();
						window.location.href = url;
					}, 1000 );
				}


			} );
		},
		addFastClickBugFixToSvgElements: function() {

			// bug in iOS -> click isn't sent to svg Element when fastclick is enabled
			// workaround: https://github.com/ftlabs/fastclick/pull/452/commits/6d1412c38b7486fd7822294f52fccc0638fbbfec
			// and add class 'needsclick' to all clickable elements

			var svg         = this.vMapWrapper.find( 'svg' );
			var svgElements = svg[0].getElementsByTagName( "*" );

			for (var i = 0; i < svgElements.length; i++) {
				var element = svgElements[i];

				var elemClass = element.getAttribute( 'class' );
				elemClass += ' needsclick';
				element.setAttribute( 'class', elemClass );
			}
		},
		addFastClickBugfixToMarker:      function() {

			// bug in iOS -> click isn't sent to svg Element when fastclick is enabled
			// workaround: https://github.com/ftlabs/fastclick/pull/452/commits/6d1412c38b7486fd7822294f52fccc0638fbbfec
			// and add class 'needsclick' to all clickable elements

			var markerElements = this.vMapWrapper.find( '.jvectormap-marker' );
			for (var i = 0; i < markerElements.length; i++) {
				var element   = markerElements[i];
				var elemClass = element.getAttribute( 'class' );

				elemClass += ' needsclick';
				element.setAttribute( 'class', elemClass );
			}
		}


	} );

	$.fn[pluginName] = function( options ) {
		return this.each( function() {
			if (!$.data( this, 'plugin_' + pluginName )) {
				$.data( this, 'plugin_' + pluginName, new Plugin( this, options ) );
			}
		} );
	};

})( jQuery, window, document );
