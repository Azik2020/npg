'use strict';


(function( $, window, document, undefined ) {
		// undefined is used here as the undefined global variable in ECMAScript 3 is
		// mutable (ie. it can be changed by someone else). undefined isn't really being
		// passed in so we can ensure the value of it is truly undefined. In ES5, undefined
		// can no longer be modified.

		// window and document are passed through as local variable rather than global
		// as this (slightly) quickens the resolution process and can be more efficiently
		// minified (especially when both are regularly referenced in your plugin).

		// Create the defaults once
		var pluginName = 'mediaCenter',
			defaults = {
				propertyName: 'value'
			};

		// The actual plugin constructor
		function Plugin ( element, options ) {
            var plugin = this;

            plugin.$element  = $( element );
            plugin._defaults = defaults;
            plugin._name     = pluginName;
            plugin.options   = $.extend( {}, defaults, options );

			plugin.currentDateformat = plugin.$element.data( 'dateformat' );
            plugin.currentVideoAmountPerRequest = parseInt(plugin.$element.data( 'items-per-page' ), 10);
            plugin.currentVideoAmountPage = 0;
            plugin.currentVideoAmountTotal = 0;
            plugin.currentVideoItems = {};

			this.init();
		}

		// Avoid Plugin.prototype conflicts
		$.extend( Plugin.prototype, {
			init: function() {

				// Place initialization logic here
				// You already have access to the DOM element and
				// the options via the instance, e.g. this.element
				// and this.settings
				// you can add more functions like the one below and
				// call them like the example bellow

                this.videoData = this.getVideoData( );

				if (typeof this.videoData.done === 'function') { // data retrieved via AJAX, so we get a Deferred object
					this.videoData.done( function( responseData ) {
						if (responseData && typeof responseData === 'object') {
							this.currentVideoItems = responseData;
							this.currentVideoAmountTotal = responseData.items.length;
							this.paintVideosForCurrentPage();
						}
					} );
				}

				this.clickHandler();
			},

			clickHandler: function() {
				var me = this;

				$( 'body' ).on( 'click', '#js_content-list-pager a:not(.active)', function () {
					$('html, body').animate({
						scrollTop: parseInt(me.$element.offset().top, 10)
					}, 500);
					me.currentVideoAmountPage = parseInt($(this).data( 'next-page' ), 10);
					me.paintVideosForCurrentPage();
				} );
			},

            digits: function( text ) {
               return text.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1.');
            },

            equalize: function( ) {
				// equalize portlet height
                const me          = this;

                if ($(window).width() > 462) {
                    me.$element.find('.equalizer').each(function () {
                        var heights = $(this).find('.statistics .h3').map(function () {
                            return $(this).height();
                        } ).get();
                        var maxHeight = Math.max.apply(null, heights);

                        $(this).find('.statistics .h3').height(maxHeight);
                    } );
                } else {
					me.$element.find('.equalizer').each(function () {
						$(this).find('.statistics .h3').height('');
					} );
				}
            },

			formatDate: function(date_text) {
				// format date
				const me          = this;

				var d = new Date(date_text.substring(0,date_text.indexOf('T')));
				var month = parseInt(d.getUTCMonth(),10) + 1;
				month = month < 10 ? '0' + month : month;
				var day = parseInt(d.getUTCDate(),10);
				day = day < 10 ? '0' + day : day;
				var year = parseInt(d.getUTCFullYear(),10);
				var formatedDate = me.currentDateformat;
				formatedDate = formatedDate
					.replace(/dd/g, day)
					.replace(/MM/g, month)
					.replace(/yyyy/g, year);

				return formatedDate;
			},

            getVideoData: function() {
                // get videos as json
                const me          = this;

                var uriData = me.$element.data( 'uri-videodata' ) || null;

                if (!uriData) {
                    throw new Error( 'media-center: You must specify an attribute data-uri-videodata for the element on which you apply this plugin.' );
                }
                return $.ajax( {
                    'url':      uriData,
                    'type':     'GET',
                    'dataType': 'json',
                    context:    this
                } );
            },

			paintPager: function() {
				// generate html code of pager
				const me          = this;
				me.$element.find('#js_content-list-pager li').remove();
				var code = '';

				if (me.currentVideoAmountPage !== 0) {
					code = code + '<li><a href="#" aria-label="Previous" class="icon-prev" data-next-page="'+ (me.currentVideoAmountPage - 1) +'"></a></li>';
				}

				var step = 0;
				var css =  '';
				var paginationPages = Math.floor(me.currentVideoAmountTotal / me.currentVideoAmountPerRequest);
				paginationPages = me.currentVideoAmountTotal %  me.currentVideoAmountPerRequest == 0 ? paginationPages : paginationPages + 1;

				for (var i = 0; i < paginationPages; i++) {
					step++;
					css = '';
					if (me.currentVideoAmountPage == (step - 1)) {
						css = 'active';
					}

					var currentMin = ((step - 1) * me.currentVideoAmountPerRequest) + 1;
					var currentMax = step * me.currentVideoAmountPerRequest;
					if (currentMax > me.currentVideoAmountTotal) {
						currentMax = me.currentVideoAmountTotal;
					}

					var link = currentMin + '-' + currentMax;
					var printPoints = false;
					var printSite = false;

					if (paginationPages > 5) {
						if (me.currentVideoAmountPage < 3) {
							if (step == 5) {
								printPoints = true;
							} else if (step == paginationPages || step < 5) {
								printSite = true;
							}
						}
						else if (me.currentVideoAmountPage + 4 > paginationPages) {
							if (step == 2) {
								printPoints = true;
							} else if (step == 1 || paginationPages - step < 4) {
								printSite = true;
							}
						}
						else {
							if (step == 1 || me.currentVideoAmountPage == step || (me.currentVideoAmountPage + 1) == step || (me.currentVideoAmountPage + 2) == step || paginationPages - step == 0) {
								printSite = true;
							} else if (step == 2 || paginationPages - step == 1) {
								printPoints = true;
							}
						}
					} else {
						printSite = true;
					}

					if (printPoints) {
						code = code + '<li><span>...</span></li>';
					} else if (printSite) {
						if (me.currentVideoAmountPage == (step - 1)) {
							code = code + '<li class="' + css + '"><a data-next-page="' + me.currentVideoAmountPage + '" href="#">' + link + '</a></li>';
						} else {
							code = code + '<li><a data-next-page="' + (step - 1) + '" href="#">' + link + '</a></li>';
						}
					}
				}

				if (((me.currentVideoAmountPage+1) * me.currentVideoAmountPerRequest) < me.currentVideoAmountTotal) {
					code = code + '<li><a href="#" aria-label="Next" class="icon-next" data-next-page="'+ (me.currentVideoAmountPage+1) +'"></a></li>';
				}

				me.$element.find('#js_content-list-pager').append(code);
			},

            paintVideosForCurrentPage: function() {
                // generate html code of videos
                const me          = this;

				var videoTpl = me.$element.find('#media-video').text();
				var videoSpinnerTpl = me.$element.find('#media-video-spinner').text();
				var videoRowStartTpl = me.$element.find('#media-video-row-start').text();
				var videoRowEndTpl = me.$element.find('#media-video-row-end').text();
				var videoItemsCountTpl = me.$element.find('#media-video-item-count-text').text();

				me.$element.find('div.row.editorial-content.equalizer, #itemCount').remove();
				me.$element.find('#media-pager').before(videoSpinnerTpl);

				var code = '';
				var rowOpen = false;
				var from = 0;
				var to = 0;
				if (me.currentVideoAmountPage !== 0) {
					from = me.currentVideoAmountPage * me.currentVideoAmountPerRequest;
					to = (me.currentVideoAmountPage+1) * me.currentVideoAmountPerRequest;
				} else {
					to = me.currentVideoAmountPerRequest;
				}
				if (to > me.currentVideoItems.items.length) {
					to = me.currentVideoItems.items.length;
				}

				var croppedVideoItems = [];
				for (var i = from; i < to; i++) {
					croppedVideoItems[croppedVideoItems.length] = me.currentVideoItems.items[i];
				}

				code = code + videoItemsCountTpl.replace(/\{{itemcount}}/g, me.currentVideoItems.items.length);

				for (var i = 0; i < croppedVideoItems.length; i++) {
					if (i == 0) {
						code = code + videoRowStartTpl;
						rowOpen = true;
					}
					if (i % 4 == 0 && i != 0) {
						code = code + videoRowEndTpl;
						code = code + videoRowStartTpl;
						rowOpen = true;
					}
					var tmpVideo = videoTpl;
					tmpVideo = tmpVideo
						.replace(/\{{youtubeid}}/g, croppedVideoItems[i].videoId)
						.replace(/\{{title}}/g, croppedVideoItems[i].snippet.title)
						.replace(/\{{date}}/g, me.formatDate(croppedVideoItems[i].snippet.publishedAt))
						.replace(/\{{hqdefault}}/g, croppedVideoItems[i].snippet.thumbnails.high.url)
						.replace(/\{{mqdefault}}/g, croppedVideoItems[i].snippet.thumbnails.medium.url)
						.replace(/\{{likes}}/g, me.digits(croppedVideoItems[i].statistics.likeCount))
						.replace(/\{{viewcount}}/g, me.digits(croppedVideoItems[i].statistics.viewCount));

					code = code + tmpVideo;
				}
				if (rowOpen) {
					code = code + videoRowEndTpl;
				}
				me.$element.find('div.row.editorial-content.equalizer').remove();
				me.$element.find('#media-pager').before(code);
				me.equalize();
				me.paintPager();
            }
		} );

		// A really lightweight plugin wrapper around the constructor,
		// preventing against multiple instantiations
		$.fn[ pluginName ] = function( options ) {
			return this.each( function() {
				if ( !$.data( this, 'plugin_' + pluginName ) ) {
					$.data( this, 'plugin_' +
						pluginName, new Plugin( this, options ) );
				}
			} );
		};

} )( jQuery, window, document );

