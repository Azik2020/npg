"use strict";

function onYouTubeIframeAPIReady() {
    $(".js_sliding-teaser").slidingTeaser("initYoutubeAPI")
}

function getIFrame() {
    $("iframe.extern").length && $.get("http://man-centre.com/templates/russian/js/iframe_resizer_min.js").done(function() {
        $("iframe.extern").iFrameResize([{}])
    })
}
$(function() {
    function a(a) {
        return this.each(function() {
            var c = $(this),
                d = c.data("bs.tab");
            d || c.data("bs.tab", d = new b(this)), "string" == typeof a && d[a]()
        })
    }
    var b = function(a) {
        this.element = $(a)
    };
    b.VERSION = "3.3.6", b.TRANSITION_DURATION = 150, b.prototype.show = function() {
        var a = this.element,
            b = a.closest("ul:not(.dropdown-menu)"),
            c = a.data("target");
        if(c || (c = a.attr("href"), c = c && c.replace(/.*(?=#[^\s]*$)/, "")), !a.parent("li").hasClass("active")) {
            var d = b.find(".active:last a"),
                e = $.Event("hide.bs.tab", {
                    relatedTarget: a[0]
                }),
                f = $.Event("show.bs.tab", {
                    relatedTarget: d[0]
                });
            if(d.trigger(e), a.trigger(f), !f.isDefaultPrevented() && !e.isDefaultPrevented()) {
                var g = $(c);
                this.activate(a.closest("li"), b), this.activate(g, g.parent(), function() {
                    d.trigger({
                        type: "hidden.bs.tab",
                        relatedTarget: a[0]
                    }), a.trigger({
                        type: "shown.bs.tab",
                        relatedTarget: d[0]
                    })
                })
            }
        }
    }, b.prototype.activate = function(a, c, d) {
        function e() {
            f.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !1), a.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded", !0), g ? (a[0].offsetWidth, a.addClass("in")) : a.removeClass("fade"), a.parent(".dropdown-menu").length && a.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !0), d && d()
        }
        var f = c.find(" .active"),
            g = d && $.support.transition && (f.length && f.hasClass("fade") || !!c.find("> .fade").length);
        f.length && g ? f.one("bsTransitionEnd", e).emulateTransitionEnd(b.TRANSITION_DURATION) : e(), f.removeClass("in")
    };
    var c = $.fn.tab;
    $.fn.tab = a, $.fn.tab.Constructor = b, $.fn.tab.noConflict = function() {
        return $.fn.tab = c, this
    };
    var d = function(b) {
        b.preventDefault(), a.call($(this), "show")
    };
    $(document).on("click.bs.tab.data-api", '[data-toggle="tab"]', d).on("click.bs.tab.data-api", '[data-toggle="pill"]', d)
});
var AreaDataService = {
        toggleExpandedAreaState: function(a) {
            "true" === a.attr("aria-expanded") ? a.attr("aria-expanded", "false") : "false" === a.attr("aria-expanded") && a.attr("aria-expanded", "true")
        },
        toggleVisibleAreaState: function(a) {
            "undefined" !== a.attr("aria-hidden") && a.attr("aria-hidden", (!a.is(":visible")).toString())
        },
        setExpandedState: function(a, b) {
            a.attr("aria-expanded", b.toString())
        },
        setHiddenState: function(a, b) {
            a.attr("aria-hidden", b.toString())
        }
    },
    I18NService = function(a, b) {
        var c = {};
        return c.data = {}, c.setData = function() {
            a.getJSON(a("body").data("i18n-json-url") || null, function(d) {
                c.data = d, a(b).trigger("i18n.initialized")
            })
        }, c.getDateFormat = function() {
            return c.data.datepicker.format
        }, c.getDatepicker = function() {
            return c.data.datepicker
        }, c.getRoutingJSONPath = function() {
            return c.data.routingJSONPath || null
        }, a(function() {
            c.setData()
        }), {
            getDatepicker: function() {
                return c.getDatepicker()
            },
            getRoutingJSONPath: function() {
                return c.getRoutingJSONPath()
            },
            getDateFormat: function() {
                return c.getDateFormat()
            }
        }
    }($, window),
    RouterDataService = function(a, b) {
        var c = {};
        return c.data = {}, c.setData = function() {
            a.getJSON(I18NService.getRoutingJSONPath(), function(d) {
                c.data = d, a(b).trigger("routerData.initialized")
            })
        }, c.getData = function() {
            return c.data
        }, a(b).on("i18n.initialized", function() {
            c.setData()
        }), {
            getData: function() {
                return c.getData()
            }
        }
    }($, window),
    NavigationService = function(a) {
        var b = {};
        return b.data = {}, b.setData = function() {
            a.getJSON(a("body").data("nav-json-url"), function(c) {
                b.data = c, a(window).trigger("nav_data.initialized")
            })
        }, b.getNestedObj = function(a, c) {
            for(var d in c)
                if(c.hasOwnProperty(d)) {
                    if(d === a) return c[d];
                    if("object" == typeof c[d]) {
                        var e = b.getNestedObj(a, c[d]);
                        if(null !== e) return e
                    }
                }
            return null
        }, b.generateSingleLink = function(a, b, c, d, e) {
            var f = "";
            return "undefined" == typeof a[b].subMenu || c ? "undefined" != typeof a[b].link && (f = e ? '<div class="col-md-6">' : "", f += '<a href="' + a[b].link + '" {{isExternal}} {{isCurrentPage}}>' + a[b].displayName + "</a>", f += e ? "</div>" : "", f = f.replace("{{isExternal}}", "undefined" != typeof a[b].isExternal && a[b].isExternal ? 'target="_blank"' : ""), f = f.replace("{{isCurrentPage}}", d === b ? 'class="current-site"' : "")) : f = '<a aria-haspopup="true" aria-expanded="false" href="#" data-nav-id="' + b + '">' + a[b].displayName + "</a>", f
        }, b.generateLinkList = function(a, c, d, e) {
            var f = "";
            for(var g in a) a.hasOwnProperty(g) && (f += b.generateSingleLink(a, g, d, c, e));
            return f
        }, a(function() {
            b.setData()
        }), {
            getNestedObj: function(a) {
                return b.getNestedObj(a, b.data)
            },
            generateLinkList: function(a, c, d, e) {
                return "string" == typeof a && (a = b.getNestedObj(a, b.data).subMenu), b.generateLinkList(a, c, d, e)
            }
        }
    }($),
    throttle = function(a, b) {
        var c = void 0,
            d = void 0;
        return function() {
            var e = this,
                f = arguments,
                g = +new Date;
            c && c + a > g ? (clearTimeout(d), d = setTimeout(function() {
                c = g, b.apply(e, f)
            }, a)) : (c = g, b.apply(e, f))
        }
    };
! function(a, b, c) {
    function d(b, c) {
        this.$elem = a(b), this.settings = a.extend({}, f, c), this.$play = this.$elem.find(".play"), this.$playOverlay = this.$elem.find(".play-overlay"), this.mediaElemContainer = b, this.$mediaElem = this.$elem.find(this.settings.mediaElem), this.mediaElem = this.$mediaElem[0], this.$volumeButton = this.$elem.find(".js_volume"), this.$fullscreen = this.$elem.find(".js_fullscreen"), this.$totalTimeMinutes = this.$elem.find(".total-time .minutes"), this.$totalTimeSeconds = this.$elem.find(".total-time .seconds"), this.$spentTimeMinutes = this.$elem.find(".spent-time .minutes"), this.$spentTimeSeconds = this.$elem.find(".spent-time .seconds"), this.actualVolume = this.mediaElem.volume, this.$progressBarContainer = this.$elem.find(".progress"), this.progressBarContainerWidth = this.$progressBarContainer.width(), this.$progressBar = this.$elem.find(".progress-bar"), this.$progressSrOnly = this.$progressBar.find(".sr-only"), this.$progressSrOnlyTextAddition = this.$progressSrOnly.data("text"), this.$volumeRange = this.$elem.find("input[type=range]"), this.isFullscreen = !1, this.currentTimeInterval = 0, this.updateProgressBarInterval = 0, this.screenChangeEvents = "fullscreenchange webkitfullscreenchange mozfullscreenchange  MSFullscreenChange", this.init()
    }
    var e = "media",
        f = {};
    a.extend(d.prototype, {
        init: function() {
            this.$mediaElem.attr("controls", !1), this.setmediaElemDuration(), this.initVolume(), this.mediaElemEventHandling(), this.initRangeSlider()
        },
        mediaElemEventHandling: function() {
            var b = this;
            b.$play.on("click", function(a) {
                a.preventDefault(), b.handlePlayPauseFunctionality(), b.togglePlayPause()
            }), Modernizr.touch ? b.$playOverlay.on("click", function() {
                b.mediaElem.currentTime > 0 && b.mediaElem.paused ? (b.handlePlayPauseFunctionality(), b.togglePlayPause()) : b.mediaElem.currentTime > 0 && !b.$elem.hasClass("state_touched") ? (b.$elem.addClass("state_touched"), setTimeout(function() {
                    b.$elem.removeClass("state_touched")
                }, 1e3)) : (b.handlePlayPauseFunctionality(), b.togglePlayPause())
            }) : (b.$playOverlay.on("click", function() {
                b.handlePlayPauseFunctionality(), b.togglePlayPause()
            }), b.$mediaElem.on("click", function() {
                b.handlePlayPauseFunctionality()
            })), b.$mediaElem.on("ended", function() {
                b.$elem.addClass("state_ended"), b.$elem.removeClass("state_playing")
            }), b.$volumeButton.on("click", function(a) {
                a.preventDefault(), b.handleMuteState()
            }), b.$fullscreen.on("click", function(a) {
                a.preventDefault(), b.handleFullscreenActions()
            }), b.$progressBarContainer.on("click", function(a) {
                var c = 0;
                if(b.isFullscreen) c = a.clientX;
                else {
                    var d = b.getElementPosition(a.currentTarget);
                    c = a.clientX - d.x
                }
                b.setProgressBarWidth(c);
                var e = (100 * c / b.progressBarContainerWidth).toFixed(0);
                b.$progressBar.attr("aria-valuenow", e + "%"), b.setProgressBarSrValue(e), b.mediaElem.currentTime = c * b.mediaElem.duration / b.progressBarContainerWidth, b.setCurrentTime()
            }), a(c).on(b.screenChangeEvents, function() {
                b.isFullscreen = c.fullScreen || c.mozFullScreen || c.webkitIsFullScreen || c.msFullscreenElement, b.progressBarContainerWidth = b.$progressBarContainer.width()
            })
        },
        initRangeSlider: function() {
            var a = this;
            a.$volumeRange.rangeslider({
                polyfill: !1,
                onSlide: function(b, c) {
                    a.mediaElem.volume = c, 0 === c ? (a.$elem.removeClass("state_volume_low"), a.$elem.addClass("state_muted")) : .5 >= c ? (a.$elem.removeClass("state_muted"), a.$elem.addClass("state_volume_low")) : c > .5 && a.$elem.removeClass("state_muted state_volume_low")
                },
                onSlideEnd: function(b, c) {
                    a.actualVolume = c, a.mediaElem.volume = a.actualVolume
                }
            })
        },
        initVolume: function() {
            var a = this;
            a.$volumeRange.val(a.mediaElem.volume).change()
        },
        handlePlayPauseFunctionality: function() {
            var a = this;
            a.$elem.hasClass("state_ended") && (a.$elem.removeClass("state_ended"), a.mediaElem.currentTime = 0, a.setProgressBarWidth(0)), a.$elem.toggleClass("state_playing"), a.mediaElem.currentTime > 0 && !a.mediaElem.paused ? (clearInterval(a.currentTimeInterval), clearInterval(a.updateProgressBarInterval)) : (a.setCurrentTime(), a.updateProgressBar())
        },
        togglePlayPause: function() {
            var a = this;
            a.mediaElem.currentTime > 0 && !a.mediaElem.paused ? a.mediaElem.pause() : a.mediaElem.play()
        },
        getElementPosition: function(a) {
            for(var b = 0, c = 0; a;) b += a.offsetLeft - a.scrollLeft + a.clientLeft, c += a.offsetTop - a.scrollTop + a.clientTop, a = a.offsetParent;
            return {
                x: b,
                y: c
            }
        },
        updateProgressBar: function() {
            var a = this;
            a.updateProgressBarInterval = setInterval(function() {
                var b = Math.ceil(a.mediaElem.currentTime * a.$progressBarContainer.width() / a.mediaElem.duration);
                a.setProgressBarWidth(b);
                var c = (100 * b / a.progressBarContainerWidth).toFixed(0);
                a.$progressBar.attr("aria-valuenow", c + "%"), a.setProgressBarSrValue(c)
            }, 1e3)
        },
        setmediaElemDuration: function() {
            var a = this,
                b = setInterval(function() {
                    if(a.mediaElem.readyState > 0) {
                        var c = a.calculatemediaElemTimes(a.mediaElem.duration);
                        a.$totalTimeMinutes.text(c[0]), a.$totalTimeSeconds.text(c[1]), clearInterval(b)
                    }
                }, 1e3)
        },
        calculatemediaElemTimes: function(a) {
            var b = [];
            b.push(parseInt(a / 60, 10));
            var c = "00" + (a % 60).toFixed(0);
            return c = c.substr(-2, c.length), b.push(c), b
        },
        setCurrentTime: function() {
            var a = this;
            a.currentTimeInterval = setInterval(function() {
                var b = a.mediaElem.currentTime,
                    c = a.calculatemediaElemTimes(b);
                a.$spentTimeMinutes.text(c[0]), a.$spentTimeSeconds.text(c[1])
            }, 1e3)
        },
        handleFullscreenActions: function() {
            var d = this,
                e = navigator.userAgent || navigator.vendor || b.opera;
            a.isFunction(d.mediaElem.enterFullscreen) ? d.isFullscreen ? c.cancelFullScreen() : d.mediaElemContainer.requestFullscreen() : Modernizr.touch && /iPad|iPhone|iPod/.test(e) && !b.MSStream && d.mediaElem.webkitSupportsFullscreen ? d.isFullscreen ? c.webkitCancelFullScreen() : d.mediaElem.webkitEnterFullscreen() : a.isFunction(d.mediaElem.webkitEnterFullscreen) ? d.isFullscreen ? c.webkitCancelFullScreen() : d.mediaElemContainer.webkitRequestFullScreen() : a.isFunction(d.mediaElem.mozRequestFullScreen) ? d.isFullscreen ? c.mozCancelFullScreen() : d.mediaElemContainer.mozRequestFullScreen() : a.isFunction(d.mediaElem.msRequestFullscreen) && (d.isFullscreen ? c.msExitFullscreen() : d.mediaElemContainer.msRequestFullscreen())
        },
        handleMuteState: function() {
            var a = this;
            a.$mediaElem.prop("muted") ? (a.mediaElem.volume = a.actualVolume, a.$volumeRange.val(a.actualVolume).change()) : a.$volumeRange.val(0).change(), a.$mediaElem.prop("muted", !a.$mediaElem.prop("muted"))
        },
        setProgressBarWidth: function(a) {
            this.$progressBar.width(a)
        },
        setProgressBarSrValue: function(a) {
            this.$progressSrOnly.html(a + "% " + this.$progressSrOnlyTextAddition)
        }
    }), a.fn[e] = function(b) {
        return this.each(function() {
            a.data(this, "plugin_" + e) || a.data(this, "plugin_" + e, new d(this, b))
        })
    }
}(jQuery, window, document), $(function() {
        $(".js_video-container").media({
            mediaElem: "video"
        }), $(".js_audio-container").media({
            mediaElem: "audio"
        })
    }),
    function(a, b) {
        function c(b, c) {
            this.element = b, this.$elem = a(b), this.settings = a.extend({}, e, c), this.$contentContainer = this.$elem.find(".modal-dialog"), this.modalTpl = a(this.settings.modalTpl).text(), this.contentTemplate = "", this.init()
        }
        var d = "modalHandling",
            e = {};
        a.extend(c.prototype, {
            init: function() {
                this.eventHandler()
            },
            eventHandler: function() {
                var c = this;
                this.$elem.on("show.bs.modal", function(c) {
                    var d = a(c.relatedTarget),
                        e = d.parents(".gallery-content");
                    b.innerWidth <= "479" && e.length <= 0 && d.hasClass("zoom") && c.preventDefault()
                }), this.$elem.on("shown.bs.modal", function(b) {
                    var d = a(b.relatedTarget),
                        e = d.data("headline") || "",
                        f = d.data("caption") || "",
                        g = d.data("tplid"),
                        h = d.data("url"),
                        i = d.data("content-variables"),
                        j = d.data("slideid");
                    switch(c.fillGeneralTplContent(e, f), !0) {
                        case "" !== h && "undefined" != typeof h:
                            a.get(h, function(a) {
                                a.indexOf("<body>") >= 0 ? (c.contentTemplate = a.split("<body>"), c.contentTemplate = c.contentTemplate[1].split("</body>"), c.fillTplContent(c.contentTemplate[0])) : c.fillTplContent(a)
                            });
                            break;
                        case "undefined" != typeof j && "" !== j:
                            var k = d.parents(".gallery-content div").html(),
                                l = d.parents(".gallery-content").find("#" + g).text();
                            l = l.replace("{{gallery_content}}", k), c.fillTplContent(l, j);
                            break;
                        case "undefined" != typeof i && "" !== i:
                            var m = a("#" + g).text();
                            for(var n in i)
                                if(i.hasOwnProperty(n)) {
                                    var o = i[n];
                                    m = m.replace("{{" + n + "}}", o)
                                }
                            c.fillTplContent(m);
                            break;
                        default:
                            c.contentTemplate = a("#" + g).text(), c.fillTplContent(c.contentTemplate)
                    }
                    a("body").on("click", ".slick-prev, .slick-next", function() {
                        var b = a(".slick-slider video");
                        b.each(function() {
                            a(this)[0].pause()
                        })
                    }), c.$elem.trigger("shown.bs.modal.content.generated")
                }), this.$elem.on("hidden.bs.modal", function() {
                    c.modalTpl = a("#js_tpl-modal").text(), c.$contentContainer.html("")
                })
            },
            initPlugins: function(a) {
                this.$contentContainer.find(".js_video-container").media({
                    mediaElem: "video"
                });
                var b = "undefined" !== a || "" !== a ? a : "0";
                this.$contentContainer.find(".js_modal-slider").slick({
                    initialSlide: b
                }), picturefill()
            },
            fillTplContent: function(a, b) {
                this.modalTpl = this.modalTpl.replace("{{modal_content}}", a), this.$contentContainer.html(this.modalTpl), this.initPlugins(b), this.$elem.modal("handleUpdate")
            },
            fillGeneralTplContent: function(a, b) {
                this.modalTpl = this.modalTpl.replace("{{modal_headline}}", a), this.modalTpl = this.modalTpl.replace("{{modal_caption}}", b)
            }
        }), a.fn[d] = function(b) {
            return this.each(function() {
                a.data(this, "plugin_" + d) || a.data(this, "plugin_" + d, new c(this, b))
            })
        }
    }(jQuery, window, document), $(function() {
        $(".js_modal").modalHandling({
            modalTpl: "#js_tpl-modal"
        })
    }),
    function(a) {
        function b(b, c) {
            this.$elem = a(b), this.settings = a.extend({}, d, c), this.init()
        }
        var c = "mobileCollapse",
            d = {
                stateClass: "state_open"
            };
        a.extend(b.prototype, {
            init: function() {
                var a = this;
                a.$elem.on("click", function() {
                    a.$elem.toggleClass(a.settings.stateClass)
                })
            }
        }), a.fn[c] = function(d) {
            return this.each(function() {
                a.data(this, "plugin_" + c) || a.data(this, "plugin_" + c, new b(this, d))
            })
        }
    }(jQuery), $(function() {
        $(".js_mobile-collapse").mobileCollapse()
    }),
    function(a) {
        function b(b, c) {
            var e = a("body[data-current-path][data-nav-json-url]");
            0 !== e.length && (this.$elem = a(b), this.settings = a.extend({}, d, c), this.currentPath = e.data("current-path"), this.currentPageID = this.currentPath[this.currentPath.length - 1], this.$navWrapper = a("#js_nav-wrapper"), this.init())
        }
        var c = "mainNavigation",
            d = {};
        a.extend(b.prototype, {
            init: function() {
                var b = this;
                a(window).on("nav_data.initialized", function() {
                    b.eventHandler()
                })
            },
            eventHandler: function() {
                var b = this;
                this.$elem.on("click", 'a[aria-haspopup="true"]:not(.js_toggle-target)', function(c) {
                    c.preventDefault(), a(this).hasClass("active") ? b.setCurrentPath() : b.openPopupFromElement(a(this))
                }).on("click", "#js_toggle-nav, #js_nav-background, .js_toggle-nav", function() {
                    b.$navWrapper.toggleClass("state_visible"), a("#js_nav-background").toggleClass("state_visible"), b.closeAll(), b.setCurrentPath()
                }).on("click", "[data-target-nav-id]", function(c) {
                    c.preventDefault(), b.openPopupFromElement(a('[data-nav-id="' + a(this).data("target-nav-id") + '"]', b.$elem))
                }).on("click", ".js_close", function() {
                    b.closeAll()
                }).on("close_nav", function() {
                    b.$navWrapper.toggleClass("state_visible"), a("#js_nav-background").toggleClass("state_visible"), b.closeAll()
                }), a("body").on("click", function(c) {
                    0 === a(c.target).closest(b.$elem).length && !a(c.target).is(b.$elem) && Modernizr.mq("(min-width: 1024px)") && b.closeAll()
                })
            },
            closeAll: function() {
                this.$navWrapper.removeClass("state_open"), AreaDataService.setExpandedState(this.$elem.find('[aria-expanded="true"]'), !1), AreaDataService.setHiddenState(this.$elem.find("[aria-hidden]"), !0)
            },
            openPopupFromElement: function(b) {
                var c = this,
                    d = b.data("nav-id"),
                    e = b.closest("[data-nav-pos]").data("nav-pos"),
                    f = NavigationService.getNestedObj(d);
                0 === a("#" + d).length && c.generateNavList(f, d, e), c.resetContainerLinks(e), c.generateMobileNavBreadcrumb(e, d, f.displayName), "undefined" != typeof e && (AreaDataService.setExpandedState(b, !0), AreaDataService.setHiddenState(a("#" + d), !1), c.$navWrapper.addClass("state_open"))
            },
            generateMobileNavBreadcrumb: function(b, c, d) {
                var e = '<a href="#" data-target-nav-id="' + c + '">' + d + "</a>",
                    f = a("#js_nav-breadcrumb"),
                    g = a("#js_nav-breadcrumb-" + (b + 1));
                0 !== g.length ? g.html(e) : g = f.children("span:first-child"), g.nextAll().text(""), f.find("a").removeClass("state_active");
                var h = f.find("span:has(a)").last().children("a");
                0 === h.length && (h = f.children("a")), h.addClass("state_active"), a(".js_scroll-container").animate({
                    scrollLeft: 1e3
                }, 300)
            },
            setCurrentPath: function() {
                for(var b = this, c = 1; c < b.currentPath.length - 1; c++) {
                    var d = b.currentPath[c],
                        e = NavigationService.getNestedObj(d);
                    b.generateMobileNavBreadcrumb(c, d, e.displayName), 0 === a("#" + b.currentPath[c]).length && b.generateNavList(e, d, c), b.openPopupFromElement(a('[data-nav-id="' + d + '"]', b.$elem))
                }
            },
            resetContainerLinks: function(b) {
                var c = a("#js_nav-container-level-" + (b + 1));
                AreaDataService.setExpandedState(a("#js_nav-container-level-" + b).find('[aria-expanded="true"]'), !1), AreaDataService.setHiddenState(c.find('[aria-hidden="false"]'), !0), 1 === c.length && this.resetContainerLinks(b + 1)
            },
            generateNavList: function(b, c, d) {
                if(0 !== d) {
                    var e = a("#js_tpl-subnav").text(),
                        f = NavigationService.generateLinkList(b.subMenu, this.currentPageID, !1, d + 1 === 4);
                    e = e.replace("{{id}}", c), e = e.replace("{{headline}}", b.displayName), e = e.replace("{{link-list}}", f);
                    var g = a(e),
                        h = a(".js_router-links:first").clone();
                    h.find(".js_toggle-target").toggleTargetPopup(), g.append(h), a("#js_nav-container-level-" + (d + 1)).append(g), Modernizr.touch ? a(".tpl_nav-item").scrollTop(0) : a(".tpl_nav-item").animate({
                        scrollTop: 0
                    }, 300)
                }
            }
        }), a.fn[c] = function(d) {
            return this.each(function() {
                a.data(this, "plugin_" + c) || a.data(this, "plugin_" + c, new b(this, d))
            })
        }
    }(jQuery), $(function() {
        $(".js_main-navigation").mainNavigation()
    }),
    function(a) {
        function b(b, c) {
            Modernizr.mq("(max-width: 1023px)") || (this.$elem = a(b), this.settings = a.extend({}, d, c), this.currentPath = a("body").data("current-path"), this.currentPageID = this.currentPath[this.currentPath.length - 1], this.tpl = a("#js_tpl-breadcrumb-flyout").text(), this.init())
        }
        var c = "breadcrumb",
            d = {};
        a.extend(b.prototype, {
            init: function() {
                var b = this;
                a(window).on("nav_data.initialized", function() {
                    b.eventHandler()
                })
            },
            eventHandler: function() {
                var b = this;
                Modernizr.touch || Modernizr.pointerevents ? this.$elem.on("click", ".js_breadcrumb-item", function() {
                    "false" === a(this).attr("aria-expanded") ? (b.closeAll(), b.showFlyout(a(this))) : b.closeAll()
                }) : this.$elem.on("mouseenter", ".js_breadcrumb-item", function() {
                    b.showFlyout(a(this))
                }).on("mouseleave", ".js_breadcrumb-item", b.close)
            },
            generateFlyout: function(a) {
                var b = this.tpl,
                    c = this.currentPath[a.index()],
                    d = NavigationService.getNestedObj(c),
                    e = null !== d ? d.displayName : "",
                    f = NavigationService.generateLinkList(c, this.currentPath[a.index() + 1], !0, !1);
                "" !== f && (b = b.replace("{{headline}}", e), b = b.replace("{{links}}", f), a.append(b))
            },
            showFlyout: function(a) {
                0 === a.children(".js_submenu-container").length && this.generateFlyout(a), AreaDataService.setExpandedState(a, !0), AreaDataService.setHiddenState(a.children(".js_submenu-container"), !1)
            },
            close: function() {
                AreaDataService.setExpandedState(a(this), !1), AreaDataService.setHiddenState(a(this).children(".js_submenu-container"), !0)
            },
            closeAll: function() {
                var a = this;
                AreaDataService.setExpandedState(a.$elem.find(".js_breadcrumb-item"), !1), AreaDataService.setHiddenState(a.$elem.find(".js_submenu-container"), !0)
            }
        }), a.fn[c] = function(d) {
            return this.each(function() {
                a.data(this, "plugin_" + c) || a.data(this, "plugin_" + c, new b(this, d))
            })
        }
    }(jQuery), $(function() {
        $(".js_breadcrumb").breadcrumb()
    }),
    function(a) {
        function b(b, c) {
            this.$elem = a(b), this.$target = a(), this.settings = a.extend({}, d, c), this.init()
        }
        var c = "toggleTargetPopup",
            d = {
                target: "#defaultDummy",
                fadeTime: 666
            };
        a.extend(b.prototype, {
            init: function() {
                var b = this;
                void 0 !== b.$elem.data("target") ? b.$target = a(b.$elem.data("target")) : void 0 !== b.$elem.attr("href") && "#" !== b.$elem.attr("href") && (b.$target = a(b.$elem.attr("href"))), 0 !== b.$target.length && b.eventHandler()
            },
            eventHandler: function() {
                var b = this;
                a(b.$elem).on("click", function(c) {
                    c.preventDefault(), c.stopPropagation(), b.toggleTarget(), b.$elem.hasClass("js_close-nav") && a(".js_main-navigation").trigger("close_nav")
                }), a("body").on("click", function(c) {
                    0 !== a(c.target).closest(b.$target).length || a(c.target).is(b.$target) || b.close()
                })
            },
            toggleTarget: function() {
                var b = this;
                b.$target.fadeToggle(this.settings.fadeTime), AreaDataService.toggleExpandedAreaState(this.$elem), AreaDataService.toggleVisibleAreaState(this.$target), b.$elem.hasClass("js_no-mobile-sticky-affix") && setTimeout(function() {
                    a(".js_mobile-sticky").toggleClass("state_has-sticky-child state_sticky-hidden")
                }, a(".js_mobile-sticky").hasClass("state_has-sticky-child") ? 200 : 0)
            },
            close: function() {
                AreaDataService.setExpandedState(this.$elem, !1), AreaDataService.setHiddenState(this.$target, !0), this.$target.fadeOut(this.settings.fadeTime), setTimeout(function() {
                    a(".js_mobile-sticky").removeClass("state_has-sticky-child state_sticky-hidden")
                }, 200)
            }
        }), a.fn[c] = function(d) {
            return this.each(function() {
                a.data(this, "plugin_" + c) || a.data(this, "plugin_" + c, new b(this, d))
            })
        }
    }(jQuery), $(function() {
        $(".js_toggle-target").toggleTargetPopup()
    }),
    function(a, b, c) {
        function d(b, d) {
            this.$elem = a(b), this.$input = a("#js_routing-autocomplete-input"), this.$resultContainer = a("#js_header-autocomplete-result-container"), this.tpl = {};
            var e = a("#js_tpl-header-autocomplete");
            this.tpl.result = e.text(), this.tpl.noResult = c.getElementById("js_tpl-header-autocomplete-no-result").textContent, this.tpl.links = e.data("link-text"), this.settings = a.extend({}, f, d), this.countries = [], this.isoCodes = {}, this.setData()
        }
        var e = "routingAutocomplete",
            f = {};
        a.extend(d.prototype, {
            init: function() {
                this.thisEventHandler()
            },
            thisEventHandler: function() {
                var a = this;
                a.$elem.on("submit", function(b) {
                    b.preventDefault(), a.$input.blur()
                }), a.$input.on("focus", function() {
                    a.$resultContainer.addClass("state_sm-min")
                }).on("blur", function() {
                    a.$resultContainer.removeClass("state_sm-min")
                }), a.$input.on("keyup", function() {
                    a.searchResult(a.$input.val())
                })
            },
            searchResult: function(a) {
                if("" === a) return void this.insertResult("");
                var b = this,
                    c = new RegExp("(^|\\s|\\b)(" + a + ")", "gi"),
                    d = {};
                this.countries.forEach(function(a) {
                    a.hasOwnProperty("name") && c.test(a.name) && (void 0 === d[a.isocode] || d[a.isocode].matchedPrio > a.prio) && (d[a.isocode] = {}, d[a.isocode].matchedPrio = a.prio, d[a.isocode].links = b.isoCodes[a.isocode].links, d[a.isocode].name = a.name.replace(c, "<strong>$2</strong>"))
                }), this.setResult(d)
            },
            setResult: function(b) {
                var c = "",
                    d = this;
                if(a.isEmptyObject(b)) c = d.tpl.noResult;
                else
                    for(var e in b)
                        if(b.hasOwnProperty(e)) {
                            c += d.tpl.result.replace("{{headline}}", b[e].name);
                            var f = "",
                                g = b[e].links;
                            for(var h in g) g.hasOwnProperty(h) && (f += '<a href="' + g[h] + '" target="_blank">' + d.tpl.links[h] + "</a>");
                            c = c.replace("{{links}}", f)
                        }
                d.insertResult(c)
            },
            insertResult: function(a) {
                this.$resultContainer.html(a)
            },
            setData: function() {
                var a = this,
                    b = RouterDataService.getData();
                a.countries = b.countries, delete b.countries, a.isoCodes = b, a.init()
            }
        }), a.fn[e] = function(b) {
            return this.each(function() {
                a.data(this, "plugin_" + e) || a.data(this, "plugin_" + e, new d(this, b))
            })
        }
    }(jQuery, window, document), $(window).on("routerData.initialized", function() {
        $("#js_routing-autocomplete").routingAutocomplete()
    }), $(function() {
        var a = $(".js_mobile-sticky");
        if(a.affix({
                offset: {
                    top: function() {
                        return this.bottom = $("#page-head").outerHeight(!0) + $(".js_mobile-sticky").outerHeight(!0)
                    },
                    bottom: 0
                }
            }), !a.length) return !0;
        var b = "state_sticky-hidden",
            c = 500,
            d = $(window),
            e = 0,
            f = 0,
            g = 0,
            h = 0,
            i = $(document),
            j = 0;
        d.on("scroll", throttle(c, function() {
            j = i.height(), e = d.height(), f = d.scrollTop(), h = g - f, 0 >= f ? a.removeClass(b) : h > 0 && a.hasClass(b) ? a.removeClass(b) : 0 > h && (f + e >= j && a.hasClass(b) ? a.removeClass(b) : a.addClass(b)), g = f
        }))
    });
var Carousel = {
    throttleTimeout: 500,
    initStage: function(a, b) {
        a.length && a.slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            asNavFor: ".stage-content-carousel",
            arrows: !1,
            fade: !0,
            dots: !0,
            autoplay: true,
  			autoplaySpeed: 10000,
            responsive: [{
                breakpoint: 1012,
                settings: {
                    fade: !1
                }
            }]
        }), b.length && b.slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: !1,
            fade: !0,
            asNavFor: ".stage-image-carousel",
            autoplay: true,
  			autoplaySpeed: 10000,
            responsive: [{
                breakpoint: 1012,
                settings: {
                    fade: !1
                }
            }]
        })
    },
    handleTabs: function(a) {
        if(a.length) {
            var b = this;
            b.handleTabSliderInitialization(a), $(window).on("resize", throttle(b.throttleTimeout, function() {
                b.handleTabSliderInitialization(a)
            }))
        }
    },
    initTabSlider: function(a) {
        a.slick({
            infinite: !1,
            slidesToShow: 1,
            speed: 300,
            arrows: !0,
            variableWidth: !0,
            autoplay: true,
  			autoplaySpeed: 10000
        })
    },
    handleTabSliderInitialization: function(a) {
        var b = this;
        a.each(function() {
            var a = $(this),
                c = a.width(),
                d = a.find("li"),
                e = 0;
            d.each(function() {
                e += $(this).outerWidth()
            }), e >= c && !a.hasClass("slick-initialized") ? b.initTabSlider(a) : c > e && a.hasClass("slick-initialized") && a.slick("unslick")
        })
    }
};
$(function() {
        Carousel.initStage($(".js_stage-image-carousel"), $(".js_stage-content-carousel")), Carousel.handleTabs($(".js_nav-tabs"))
    }),
    function() {
        function a(b, d) {
            function e(a, b) {
                return function() {
                    return a.apply(b, arguments)
                }
            }
            var f;
            if(d = d || {}, this.trackingClick = !1, this.trackingClickStart = 0, this.targetElement = null, this.touchStartX = 0, this.touchStartY = 0, this.lastTouchIdentifier = 0, this.touchBoundary = d.touchBoundary || 10, this.layer = b, this.tapDelay = d.tapDelay || 200, this.tapTimeout = d.tapTimeout || 700, !a.notNeeded(b)) {
                for(var g = ["onMouse", "onClick", "onTouchStart", "onTouchMove", "onTouchEnd", "onTouchCancel"], h = this, i = 0, j = g.length; j > i; i++) h[g[i]] = e(h[g[i]], h);
                c && (b.addEventListener("mouseover", this.onMouse, !0), b.addEventListener("mousedown", this.onMouse, !0), b.addEventListener("mouseup", this.onMouse, !0)), b.addEventListener("click", this.onClick, !0), b.addEventListener("touchstart", this.onTouchStart, !1), b.addEventListener("touchmove", this.onTouchMove, !1), b.addEventListener("touchend", this.onTouchEnd, !1), b.addEventListener("touchcancel", this.onTouchCancel, !1), Event.prototype.stopImmediatePropagation || (b.removeEventListener = function(a, c, d) {
                    var e = Node.prototype.removeEventListener;
                    "click" === a ? e.call(b, a, c.hijacked || c, d) : e.call(b, a, c, d)
                }, b.addEventListener = function(a, c, d) {
                    var e = Node.prototype.addEventListener;
                    "click" === a ? e.call(b, a, c.hijacked || (c.hijacked = function(a) {
                        a.propagationStopped || c(a)
                    }), d) : e.call(b, a, c, d)
                }), "function" == typeof b.onclick && (f = b.onclick, b.addEventListener("click", function(a) {
                    f(a)
                }, !1), b.onclick = null)
            }
        }
        var b = navigator.userAgent.indexOf("Windows Phone") >= 0,
            c = navigator.userAgent.indexOf("Android") > 0 && !b,
            d = /iP(ad|hone|od)/.test(navigator.userAgent) && !b,
            e = d && /OS 4_\d(_\d)?/.test(navigator.userAgent),
            f = d && /OS [6-7]_\d/.test(navigator.userAgent),
            g = navigator.userAgent.indexOf("BB10") > 0;
        a.prototype.needsClick = function(a) {
            switch(a.nodeName.toLowerCase()) {
                case "button":
                case "select":
                case "textarea":
                    if(a.disabled) return !0;
                    break;
                case "input":
                    if(d && "file" === a.type || a.disabled) return !0;
                    break;
                case "label":
                case "iframe":
                case "video":
                    return !0
            }
            return /\bneedsclick\b/.test(a.getAttribute("class"))
        }, a.prototype.needsFocus = function(a) {
            switch(a.nodeName.toLowerCase()) {
                case "textarea":
                    return !0;
                case "select":
                    return !c;
                case "input":
                    switch(a.type) {
                        case "button":
                        case "checkbox":
                        case "file":
                        case "image":
                        case "radio":
                        case "submit":
                            return !1
                    }
                    return !a.disabled && !a.readOnly;
                default:
                    return /\bneedsfocus\b/.test(a.getAttribute("class"))
            }
        }, a.prototype.sendClick = function(a, b) {
            var c, d;
            document.activeElement && document.activeElement !== a && document.activeElement.blur(), d = b.changedTouches[0], c = document.createEvent("MouseEvents"), c.initMouseEvent(this.determineEventType(a), !0, !0, window, 1, d.screenX, d.screenY, d.clientX, d.clientY, !1, !1, !1, !1, 0, null), c.forwardedTouchEvent = !0, a.dispatchEvent(c)
        }, a.prototype.determineEventType = function(a) {
            return c && "select" === a.tagName.toLowerCase() ? "mousedown" : "click"
        }, a.prototype.focus = function(a) {
            var b;
            d && a.setSelectionRange && 0 !== a.type.indexOf("date") && "time" !== a.type && "month" !== a.type ? (b = a.value.length, a.setSelectionRange(b, b)) : a.focus()
        }, a.prototype.updateScrollParent = function(a) {
            var b, c;
            if(b = a.fastClickScrollParent, !b || !b.contains(a)) {
                c = a;
                do {
                    if(c.scrollHeight > c.offsetHeight) {
                        b = c, a.fastClickScrollParent = c;
                        break
                    }
                    c = c.parentElement
                } while (c)
            }
            b && (b.fastClickLastScrollTop = b.scrollTop)
        }, a.prototype.getTargetElementFromEventTarget = function(a) {
            return a.nodeType === Node.TEXT_NODE ? a.parentNode : a
        }, a.prototype.onTouchStart = function(a) {
            var b, c, f;
            if(a.targetTouches.length > 1) return !0;
            if(b = this.getTargetElementFromEventTarget(a.target), c = a.targetTouches[0], d) {
                if(f = window.getSelection(), f.rangeCount && !f.isCollapsed) return !0;
                if(!e) {
                    if(c.identifier && c.identifier === this.lastTouchIdentifier) return a.preventDefault(), !1;
                    this.lastTouchIdentifier = c.identifier, this.updateScrollParent(b)
                }
            }
            return this.trackingClick = !0, this.trackingClickStart = a.timeStamp, this.targetElement = b, this.touchStartX = c.pageX, this.touchStartY = c.pageY, a.timeStamp - this.lastClickTime < this.tapDelay && a.preventDefault(), !0
        }, a.prototype.touchHasMoved = function(a) {
            var b = a.changedTouches[0],
                c = this.touchBoundary;
            return Math.abs(b.pageX - this.touchStartX) > c || Math.abs(b.pageY - this.touchStartY) > c ? !0 : !1
        }, a.prototype.onTouchMove = function(a) {
            return this.trackingClick ? ((this.targetElement !== this.getTargetElementFromEventTarget(a.target) || this.touchHasMoved(a)) && (this.trackingClick = !1, this.targetElement = null), !0) : !0
        }, a.prototype.findControl = function(a) {
            return void 0 !== a.control ? a.control : a.htmlFor ? document.getElementById(a.htmlFor) : a.querySelector("button, input:not([type=hidden]), keygen, meter, output, progress, select, textarea")
        }, a.prototype.onTouchEnd = function(a) {
            var b, g, h, i, j, k = this.targetElement;
            if(!this.trackingClick) return !0;
            if(a.timeStamp - this.lastClickTime < this.tapDelay) return this.cancelNextClick = !0, !0;
            if(a.timeStamp - this.trackingClickStart > this.tapTimeout) return !0;
            if(this.cancelNextClick = !1, this.lastClickTime = a.timeStamp, g = this.trackingClickStart, this.trackingClick = !1, this.trackingClickStart = 0, f && (j = a.changedTouches[0], k = document.elementFromPoint(j.pageX - window.pageXOffset, j.pageY - window.pageYOffset) || k, k.fastClickScrollParent = this.targetElement.fastClickScrollParent), h = k.tagName.toLowerCase(), "label" === h) {
                if(b = this.findControl(k)) {
                    if(this.focus(k), c) return !1;
                    k = b
                }
            } else if(this.needsFocus(k)) return a.timeStamp - g > 100 || d && window.top !== window && "input" === h ? (this.targetElement = null, !1) : (this.focus(k), this.sendClick(k, a), d && "select" === h || (this.targetElement = null, a.preventDefault()), !1);
            return d && !e && (i = k.fastClickScrollParent, i && i.fastClickLastScrollTop !== i.scrollTop) ? !0 : (this.needsClick(k) || (a.preventDefault(), this.sendClick(k, a)), !1)
        }, a.prototype.onTouchCancel = function() {
            this.trackingClick = !1, this.targetElement = null
        }, a.prototype.onMouse = function(a) {
            return this.targetElement ? a.forwardedTouchEvent ? !0 : a.cancelable && (!this.needsClick(this.targetElement) || this.cancelNextClick) ? (a.stopImmediatePropagation ? a.stopImmediatePropagation() : a.propagationStopped = !0, a.stopPropagation(), a.preventDefault(), !1) : !0 : !0
        }, a.prototype.onClick = function(a) {
            var b;
            return this.trackingClick ? (this.targetElement = null, this.trackingClick = !1, !0) : "submit" === a.target.type && 0 === a.detail ? !0 : (b = this.onMouse(a), b || (this.targetElement = null), b)
        }, a.prototype.destroy = function() {
            var a = this.layer;
            c && (a.removeEventListener("mouseover", this.onMouse, !0), a.removeEventListener("mousedown", this.onMouse, !0), a.removeEventListener("mouseup", this.onMouse, !0)), a.removeEventListener("click", this.onClick, !0), a.removeEventListener("touchstart", this.onTouchStart, !1), a.removeEventListener("touchmove", this.onTouchMove, !1), a.removeEventListener("touchend", this.onTouchEnd, !1), a.removeEventListener("touchcancel", this.onTouchCancel, !1)
        }, a.notNeeded = function(a) {
            var b, d, e, f;
            if("undefined" == typeof window.ontouchstart) return !0;
            if(d = +(/Chrome\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[1]) {
                if(!c) return !0;
                if(b = document.querySelector("meta[name=viewport]")) {
                    if(-1 !== b.content.indexOf("user-scalable=no")) return !0;
                    if(d > 31 && document.documentElement.scrollWidth <= window.outerWidth) return !0
                }
            }
            if(g && (e = navigator.userAgent.match(/Version\/([0-9]*)\.([0-9]*)/), e[1] >= 10 && e[2] >= 3 && (b = document.querySelector("meta[name=viewport]")))) {
                if(-1 !== b.content.indexOf("user-scalable=no")) return !0;
                if(document.documentElement.scrollWidth <= window.outerWidth) return !0
            }
            return "none" === a.style.msTouchAction || "manipulation" === a.style.touchAction ? !0 : (f = +(/Firefox\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[1], f >= 27 && (b = document.querySelector("meta[name=viewport]"), b && (-1 !== b.content.indexOf("user-scalable=no") || document.documentElement.scrollWidth <= window.outerWidth)) ? !0 : "none" === a.style.touchAction || "manipulation" === a.style.touchAction ? !0 : !1)
        }, a.attach = function(b, c) {
            return new a(b, c)
        }, "function" == typeof define && "object" == typeof define.amd && define.amd ? define(function() {
            return a
        }) : "undefined" != typeof module && module.exports ? (module.exports = a.attach, module.exports.FastClick = a) : window.FastClick = a
    }(), $(function() {
        FastClick.attach(document.body)
    }), window.youtubeIsLoaded = !1,
    function(a, b) {
        function c(b, c) {
            this.$elem = a(b), this.$teaserContainer = this.$elem.children(".teaser-container"), this.settings = a.extend({}, e, c), this.$youtubeContainer = this.$elem.find(".youttube-container"), this.hasYoutube = this.$youtubeContainer.length > 0, this.hasVideo = this.$elem.find(".js_video-container").length > 0, this.hasSlick = !0, this.slickIsPaused = !0, this.teaserIsSlidedOutView = !0, this.init()
        }
        var d = "slidingTeaser",
            e = {};
        a.extend(c.prototype, {
            init: function() {
                var a = this;
                a.initSlick(), a.initToggleContent(), a.getYoutubeAPI(), a.pauseSliderOnVideoPlay(), a.toggleAutoplayModal()
            },
            initSlick: function() {
                if(this.$teaserContainer.find(".teaser").length < 2) return this.hasSlick = !1, void a(".sliding-controls", this.$elem).remove();
                var b = this;
                b.$teaserContainer.on("init", function() {
                    setTimeout(function() {
                        b.checkIfIsInViewport()
                    }, 5e3)
                }), b.$teaserContainer.slick({
                    dots: !0,
                    prevArrow: b.$elem.find(".slick-prev"),
                    nextArrow: b.$elem.find(".slick-next"),
                    appendDots: b.$elem.find(".dot-container"),
                    adaptiveHeight: !0,
                    autoplay: !1,
                    autoplaySpeed: 7e3,
                    pauseOnHover: !0
                }).on("beforeChange", function() {
                    return b.pauseVideo(), !1
                }).on("afterChange", function() {
                    return b.$teaserContainer.closest(".marginal-column").length && a(".marginal-column > .row").trigger("babylongrid:resize"), !1
                }), b.$elem.find(".dot-container").on("click", function() {
                    b.pauseSlider()
                })
            },
            initToggleContent: function() {
                if(0 !== this.$elem.find(".js_toggle-content").length) {
                    var b = this;
                    b.$elem.find(".js_toggle-content").on("click", function() {
                        a(this).nextAll(".js_content").slideToggle(), a(this).toggleClass("state_closed"), AreaDataService.toggleExpandedAreaState(a(this)), AreaDataService.toggleVisibleAreaState(a(this).nextAll(".js_content"))
                    })
                }
            },
            pauseSliderOnVideoPlay: function() {
                var b = this;
                this.hasVideo && a("video", b.$teaserContainer).on("play", function() {
                    b.pauseSlider()
                }).on("ended", function() {
                    b.startSlider()
                })
            },
            getYoutubeAPI: function() {
                if(this.hasYoutube && !b.youtubeIsLoaded) {
                    var a = document.createElement("script");
                    a.src = "https://www.youtube.com/iframe_api";
                    var c = document.getElementsByTagName("script")[0];
                    c.parentNode.insertBefore(a, c), b.youtubeIsLoaded = !0
                }
            },
            initYoutubeAPI: function(b) {
                if(this.hasYoutube) {
                    var c = this;
                    b = b || c.$youtubeContainer, b.each(function() {
                        var b = a(this),
                            d = new YT.Player(b.find("iframe")[0], {
                                events: {
                                    onStateChange: function(a) {
                                        (1 === a.data || 0 === a.data) && c.pauseSlider()
                                    }
                                }
                            });
                        b.data("youtubeplayer", d)
                    })
                }
            },
            pauseVideo: function() {
                var b = this;
                a("video", b.$teaserContainer).each(function() {
                    this.pause()
                }), a(".youttube-container", b.$teaserContainer).each(function() {
                    var c = a(this).data("youtubeplayer");
                    "undefined" == typeof c && (b.initYoutubeAPI(a(this)), c = a(this).data("youtubeplayer")), setTimeout(function() {
                        "function" == typeof c.getCurrentTime && c.getCurrentTime() > 0 && c.pauseVideo()
                    }, 300)
                })
            },
            pauseSlider: function() {
                var a = this;
                a.slickIsPaused || (a.$teaserContainer.slick("slickPause"), a.slickIsPaused = !0)
            },
            startSlider: function() {
                var a = this;
                a.slickIsPaused && (a.$teaserContainer.slick("slickPlay"), a.slickIsPaused = !1)
            },
            toggleAutoplayModal: function() {
                var c = this;
                a(b).on("shown.bs.modal", function() {
                    c.pauseSlider()
                }).on("hidden.bs.modal", function() {
                    c.startSlider()
                })
            },
            checkIfIsInViewport: function() {
                var c = this,
                    d = a(b);
                setInterval(function() {
                    var a = d.scrollTop(),
                        b = a + d.height(),
                        e = c.$elem.offset().top,
                        f = e + c.$elem.height();
                    a > f - 100 || e > b ? c.teaserIsSlidedOutView || (c.pauseSlider(), c.teaserIsSlidedOutView = !0) : c.teaserIsSlidedOutView && (c.startSlider(), c.teaserIsSlidedOutView = !1)
                }, 500)
            }
        }), a.fn[d] = function(b) {
            var e = arguments;
            if(void 0 === b || "object" == typeof b) return this.each(function() {
                a.data(this, "plugin_" + d) || a.data(this, "plugin_" + d, new c(this, b))
            });
            if("string" == typeof b) {
                var f;
                return this.each(function() {
                    var g = a.data(this, "plugin_" + d);
                    g instanceof c && "function" == typeof g[b] && (f = g[b].apply(g, Array.prototype.slice.call(e, 1)))
                }), void 0 !== f ? f : this
            }
        }
    }(jQuery, window), $(function() {
        $(".js_sliding-teaser").slidingTeaser()
    }),
    function(a, b, c, d) {
        function e(b, c) {
            this.$select = a(b), this.settings = a.extend({}, g, c), this.init()
        }
        var f = "formValidation",
            g = {
                errorMarkerClass: "js_errorMarker",
                invalidClass: "has-error",
                inlineValidationTypes: "input:text, input[type=email], input:radio, input:checkbox, textarea",
                submitValidationTypes: "input:not(:hidden), input:radio, input:checkbox, select, textarea",
                halfreqTypes: "[data-halfreq=halfreq]"
            };
        a.extend(e.prototype, {
            init: function() {
                var a = this;
                a.$select.attr("novalidate", "novalidate"), a.eventHandler.formSubmit(a), a.eventHandler.leaveInput(a), a.eventHandler.leaveSelect(a)
            },
            eventHandler: {
                leaveInput: function(b) {
                    a(b.settings.inlineValidationTypes, b.$select).on("blur change", function() {
                        var c = a(this),
                            d = a(b.settings.halfreqTypes, a(b.$select));
                        if("halfreq" === c.data("halfreq")) {
                            var e = b.validate.me(d, b);
                            e === !1 ? b.markAs.valid(d, b) : e === !0 && b.markAs.invalid(c, b)
                        } else if(c.is(":required")) {
                            var f = b.validate.me(c, b);
                            f ? b.markAs.invalid(c, b) : b.markAs.valid(c, b)
                        }
                    })
                },
                leaveSelect: function(b) {
                    a(b.$select).find("select").on("blur change", function() {
                        var c = a(this);
                        if(c.is(":required")) {
                            var d = b.validate.me(c, b);
                            d ? b.markAs.invalid(c, b) : b.markAs.valid(c, b)
                        }
                    })
                },
                formSubmit: function(b) {
                    a(b.$select).on("submit", function(c) {
                        var e = !1,
                            f = a(b.settings.submitValidationTypes, this),
                            g = a(b.settings.halfreqTypes, this),
                            h = !1;
                        if(f.each(function() {
                                var c = a(this);
                                if("halfreq" === c.data("halfreq")) e = b.validate.me(g, b), e === !1 ? b.markAs.valid(g, b) : e === !0 && (b.markAs.invalid(c, b), h = !0);
                                else if(c.is(":required")) {
                                    var f = b.validate.me(c, b);
                                    f ? (b.markAs.invalid(c, b), h = !0) : b.markAs.valid(c, b)
                                } else "" === c.val() && c.data("default") !== d && c.val(c.data("default"))
                            }), h) {
                            c.stopPropagation(), c.preventDefault();
                            var i = a("html, body"),
                                j = b.$select.closest(".modal");
                            return j.length > 0 && (i = j), i.animate({
                                scrollTop: a("." + b.settings.invalidClass, b.$select).eq(0).offset().top - 100
                            }, 1e3), !1
                        }
                        return !0
                    })
                }
            },
            validate: {
                me: function(b, c) {
                    var d = !1;
                    return b.each(function() {
                        var b = a(this);
                        return d = b.is("select") ? c.validate.select(b) : b.is(":radio") ? c.validate.group(b, c.$select) : c.validate.textualInput(b), d === !1 ? d : void 0
                    }), d
                },
                select: function(a) {
                    return !a.children("option:selected").length || "" === a.children("option:selected").val()
                },
                group: function(b, c) {
                    var d = a("input[name=" + b.attr("name") + "]", c);
                    return !d.filter(":checked").length
                },
                textualInput: function(a) {
                    return "" === a.val() || a.is(":checkbox") && !a.is(":checked")
                }
            },
            markAs: {
                invalid: function(b, c) {
                    b.each(function() {
                        var b = a(this).closest("." + c.settings.errorMarkerClass);
                        b.addClass(c.settings.invalidClass)
                    })
                },
                valid: function(b, c) {
                    b.each(function() {
                        var b = a(this).closest("." + c.settings.errorMarkerClass);
                        b.removeClass(c.settings.invalidClass)
                    })
                }
            }
        }), a.fn[f] = function(b) {
            return this.each(function() {
                a.data(this, "plugin_" + f) || a.data(this, "plugin_" + f, new e(this, b))
            })
        }
    }(jQuery, window, document), $(function() {
        $(".js_form-validation").formValidation(), $(".js_async-form").each(function() {
            var a = $(this);
            setTimeout(function() {
                a.attr("action", a.data("action"))
            }, 4e3)
        })
    }),
    function(a) {
        function b(b) {
            this.$elem = a(b), this.$select = this.$elem.closest("form"), this.collectionSelector = '[data-collection="' + this.$elem.data("collection") + '"]:checkbox', this.eventHandler()
        }
        var c = "checkboxCollection";
        a.extend(b.prototype, {
            eventHandler: function() {
                var b = this;
                a(b.$select).on("change", b.collectionSelector, function() {
                    var c = [];
                    a(b.collectionSelector + ":checked", b.$select).each(function() {
                        c.push(a(this).val())
                    }), b.$elem.val(c.toString(", "))
                })
            }
        }), a.fn[c] = function() {
            return this.each(function() {
                a.data(this, "plugin_" + c) || a.data(this, "plugin_" + c, new b(this))
            })
        }
    }(jQuery), $(function() {
        $(".js_checkbox-collection").checkboxCollection()
    }),
    function(a) {
        function b(b, c) {
            this.$elem = a(b), this.$target = a(), this.settings = a.extend({}, d, c), this.init()
        }
        var c = "conditionalSelect",
            d = {
                target: "#defaultDummy",
                fadeTime: 666
            };
        a.extend(b.prototype, {
            init: function() {
                var b = this;
                b.$target = a(b.$elem.data("target-select")), b.eventHandler()
            },
            eventHandler: function() {
                var b = this;
                a(b.$elem).on("change", function(c) {
                    c.preventDefault(), b.setTargetOptions(a(this).children("option:selected"))
                })
            },
            setTargetOptions: function(a) {
                var b = a.data("target-options");
                this.setTarget(b, a.is("[data-disable-target]"))
            },
            setTarget: function(a, b) {
                this.$target.prop("disabled", b);
                for(var c = "", d = 0; d < a.length; d++) {
                    var e = a[d].val,
                        f = a[d].text,
                        g = 'data-optid="' + a[d].optid + '"' || "";
                    c += '<option value="' + e + '" ' + g + ">" + f + "</option>"
                }
                this.$target.html(c)
            }
        }), a.fn[c] = function(d) {
            return this.each(function() {
                a.data(this, "plugin_" + c) || a.data(this, "plugin_" + c, new b(this, d))
            })
        }
    }(jQuery), $(function() {
        $(".js_conditional-select").conditionalSelect()
    }),
    function(a) {
        function b(b) {
            this.$select = a(b), this.actionTpl = this.$select.data("action-template"), this.eventHandler()
        }
        var c = "actionManipulator";
        a.extend(b.prototype, {
            eventHandler: function() {
                var b = this;
                b.$select.on("change", function() {
                    var c = a(this).children("option:selected").data("optid");
                    if(void 0 !== c) {
                        var d = b.actionTpl.replace("{{optid}}", c);
                        b.$select.closest("form").attr("action", d)
                    }
                })
            }
        }), a.fn[c] = function() {
            return this.each(function() {
                a.data(this, "plugin_" + c) || a.data(this, "plugin_" + c, new b(this))
            })
        }
    }(jQuery), $(function() {
        $(".js_action-manipulator").actionManipulator()
    }),
    function(a) {
        function b(b, c) {
            this.$elem = a(b), this.settings = a.extend({}, d, c), this.$periodWrapper = a(".js_period-wrapper", b), this.$buttons = a(".js_toggle-period", b), this.$filterCheckboxes = a(".js_timeline-filter input", b), this.init()
        }
        var c = "timeline",
            d = {
                buttons: ".js_toggle-period",
                wrapper: ".js_period-wrapper",
                target: ".js_period",
                fadeTime: 666
            };
        a.extend(b.prototype, {
            init: function() {
                var b = this;
                b.$elem.length && (b.$categoryWrapper = a("[data-category]"), b.setPeriodFilter(), b.eventHandler())
            },
            eventHandler: function() {
                var b = this;
                this.$buttons.on("click", function() {
                    b.toggleElement(a(this))
                }), this.$filterCheckboxes.on("change", function() {
                    var c = [];
                    b.$filterCheckboxes.filter(":checked").each(function() {
                        c.push(a(this).data("filter"))
                    }), b.filter(c)
                })
            },
            toggleElement: function(a) {
                var b = a.closest(this.settings.wrapper).find(this.settings.target);
                b.stop(!0, !0).slideToggle(this.settings.fadeTime), AreaDataService.setHiddenState(b, "true" === b.attr("aria-hidden")), AreaDataService.toggleExpandedAreaState(a)
            },
            setPeriodFilter: function() {
                var b = this;
                b.$periodWrapper.each(function() {
                    var b = [];
                    a(this).find(".js_timeslot").each(function() {
                        for(var c = a(this).data("category"), d = 0; d < c.length; d++) - 1 === a.inArray(c[d], b) && b.push(c[d])
                    }), a(this).data("category", b)
                })
            },
            filter: function(b) {
                var c = a.merge(this.$categoryWrapper, this.$periodWrapper),
                    d = a();
                c.each(function() {
                    for(var c = a(this).data("category"), e = 0; e < b.length; e++) a.inArray(b[e], c) >= 0 && (d = a.merge(d, a(this)))
                }), c.not(d).slideUp(), d.slideDown()
            }
        }), a.fn[c] = function(d) {
            return this.each(function() {
                a.data(this, "plugin_" + c) || a.data(this, "plugin_" + c, new b(this, d))
            })
        }
    }(jQuery), $(function() {
        $(".js_timeline").timeline()
    }),
    function(a, b) {
        function c() {
            a(".js_toggle-content-list-filter", m).on("click", function() {
                a(this).hasClass("dropup") ? m.submit() : (n.slideDown(), a(this).addClass("dropup"))
            })
        }

        function d(b) {
            b = b || m, a("#js_next-page", m).val(0), b.find("input:text").val(""), b.find("input:checkbox:not([readonly])").prop("checked", !1), b.find("input.js_state-isChanged").val("0")
        }

        function e() {
            a("[data-reset-area]", m).on("click", function() {
                var b = a('[data-area="' + this.getAttribute("data-reset-area") + '"]', m);
                d(b), m.submit()
            })
        }

        function f() {
            a(".js_reset-form", m).on("click", function() {
                d()
            })
        }

        function g() {
            a("[data-toggle-area]", m).on("click", function() {
                var b = a('[data-area="' + this.getAttribute("data-toggle-area") + '"]', m),
                    c = a(this).data("check-all");
                b.find("input:checkbox").prop("checked", c), setTimeout(function() {
                    b.find(".js_state-isChanged").val(Number(!c))
                }, 50)
            })
        }

        function h() {
            var c = a("#js_datepicker"),
                d = a(".js_datepicker-input-wrapper", c),
                e = a(".js_range-start", c),
                f = a(".js_range-end", c);
            c.length && (a.fn.datepicker.dates.currentLanguage = b.getDatepicker(), c.datepicker({
                inputs: a(".js_range-start, .js_range-end"),
                disableTouchKeyboard: !0,
                language: "currentLanguage"
            }).on("changeDate", function(b) {
                a(b.target.getAttribute("data-target-input")).val(b.format())
            }), e.datepicker("update", a(e.data("target-input")).val()), f.datepicker("setDate", a(f.data("target-input")).val()), c.on("changeDate", function(b) {
                a(b.target).slideUp(), a(b.target).parents("[data-area]").find(".js_state-isChanged").val(1)
            }), d.on("click", function() {
                a(this).next().slideDown()
            }))
        }

        function i() {
            a("#js_content-list-pager").on("click", "a", function(b) {
                b.preventDefault(), a("#js_next-page").val(a(this).data("next-page")), m.submit()
            })
        }

        function j() {
            a("[data-mobile-collapse-target]", m).on("click", function() {
                var b = a('[data-mobile-collapse-wrapper="' + this.getAttribute("data-mobile-collapse-target") + '"]', m);
                a(this).toggleClass("state_open"), b.slideToggle()
            })
        }

        function k() {
            var b = a(".js_inverted-checkbox-submit-container", m);
            b.each(function() {
                var b = a(this).find("input:checkbox");
                b.length === b.filter(":checked").length && b.prop("checked", !1)
            }), m.on("submit", function() {
                n.slideUp(100), a(".js_state-isChanged", m).each(function() {
                    var b = a(this).closest("[data-area]"),
                        c = b.find(":checkbox");
                    if(c.length > 0) {
                        var d = 0 !== c.filter(":checked").length || c.filter(":checked").length === c.length ? 1 : 0;
                        a(this).val(d)
                    }
                }), b.each(function() {
                    var b = a(this).find("input:checkbox");
                    0 === b.filter(":checked").length && b.prop("checked", !0)
                })
            })
        }

        function l() {
            c(), e(), h(), g(), f(), j(), k(), i()
        }
        var m = a("#js_content-list-filter"),
            n = a("#js_content-list-filter-wrapper");
        0 !== m.length && a(window).on("i18n.initialized", function() {
            l()
        })
    }($, I18NService),
    function(a) {
        var b = a("#js_turntable"),
            c = function() {
                var b = document.createElement("script");
                b.type = "text/javascript", b.src = "http://man-centre.com/templates/russian/js/imagerotator.js", a("body").append(b)
            },
            d = function() {
                var c = void 0,
                    d = setInterval(function() {
                        10 === c ? b.remove() : a.fn.rotator && (clearInterval(d), b.rotator({
                            licenseFileURL: b.data("rotator-lisence"),
                            configFileURL: b.data("rotator-xml"),
                            graphicsPath: "",
                            zIndexLayersOn: !0
                        })), c++
                    }, 500)
            },
            e = function() {
                var b = a("#js_turntable-controls");
                b.on("click touchstart touchend mousedown mouseup", "[data-target]", function(b) {
                    var c = b.type;
                    switch(b.type) {
                        case "touchstart":
                            c = "mousedown";
                            break;
                        case "touchend":
                            c = "mouseup";
                            break;
                        case "click":
                            a(this).toggleClass("state_activated")
                    }
                    a(this.getAttribute("data-target")).trigger(c)
                }).on("click", ".js_toggle-hotspots", function() {
                    a("#js_turntable-hotspots").fadeToggle()
                })
            };
        a(function() {
            0 !== b.length && (c(), d(), e())
        })
    }($), $(function() {
        $("body").on("submit", "#js_set-server-cookie", function(a) {
            var b = $(this);
            if(!b.data("cookieIsSetted")) {
                a.stopPropagation(), a.preventDefault();
                var c = b.data("cookie-url"),
                    d = b.data("cookie-site");
                return $.get(c, {
                    site: d
                }, function() {
                    b.data("cookieIsSetted", !0), b.submit()
                }), !1
            }
        })
    }),
    function(a, b, c, d) {
        a(function() {
            var e = a("#js_to-top_page-share-container");
            if(0 !== e.length) {
                var f = a(".js_to-top", e),
                    g = a(".js_toggle-target", e),
                    h = 0,
                    i = 0;
                f.on("click", function() {
                    d.touch ? c.scrollTo(0, 0) : a("html, body").animate({
                        scrollTop: 0
                    }, 600)
                }), setInterval(function() {
                    var c = a(b).scrollTop();
                    c > h ? (e.slideUp(500), g.toggleTargetPopup("close"), i = 0) : h === c && i > 10 ? (e.slideUp(500), g.toggleTargetPopup("close")) : (e.slideDown(500), i = 0), i++, h = c
                }, 500)
            }
        })
    }($, document, window, Modernizr);
var facilitiesLegendSettings = {
        series: {
            regions: [{
                scale: {
                    production: "#303C49",
                    cooperation: "#acb1b6"
                },
                values: {},
                scrollable: !1,
                attribute: "fill",
                legend: {
                    vertical: !0,
                    labelRender: function(a) {
                        return {
                            production: "Produktionsstandorte",
                            cooperation: "Standorte Kooperationspartner"
                        }[a]
                    }
                }
            }]
        }
    },
    routerMapCountryData = {};
! function(a) {
    a(function() {
        var b = !1;
        a("#routerMap").length && a(window).on("routerData.initialized", function() {
            var c = RouterDataService.getData();
            for(var d in c) "countries" !== d && (routerMapCountryData[d] = c[d]);
            b ? a("#routerMap").find("figure").mapBuilder(a("#routerMap").find("figure").data().hasOwnProperty("loadOwnCountrydata") ? {
                mapType: "map-router"
            } : {
                values: routerMapCountryData,
                mapType: "map-router"
            }) : a.getScript("http://man-centre.com/templates/russian/js/jquery_jvectormap_min.js").done(function() {
                a.getScript("http://man-centre.com/templates/russian/js/mapbuilder.js").done(function() {
                    a("#routerMap").find("figure").mapBuilder(a("#routerMap").find("figure").data().hasOwnProperty("loadOwnCountrydata") ? {
                        mapType: "map-router"
                    } : {
                        values: routerMapCountryData,
                        mapType: "map-router"
                    }), b = !0
                })
            })
        }), (a("#facilitiesMap").length || a("#map").length) && (b ? a("#map, #facilitiesMap").length && a("#facilitiesMap, #map").find("figure").mapBuilder({
            mapSettings: facilitiesLegendSettings
        }) : a.getScript("http://man-centre.com/templates/russian/js/jquery_jvectormap_min.js").done(function() {
            a.getScript("http://man-centre.com/templates/russian/js/mapbuilder.js").done(function() {
                a("#map, #facilitiesMap").length && a("#facilitiesMap, #map").find("figure").mapBuilder({
                    mapSettings: facilitiesLegendSettings
                }), b = !0
            })
        }))
    })
}($), $(function() {
        getIFrame(), $(window).on("shown.bs.modal.content", function() {
            getIFrame()
        })
    }),
    function(a) {
        function b(b, c) {
            this.$elem = a(b), this.$parent = this.$elem.closest('[role="tablist"]'), this.$contentContainer = this.$parent.find('[role="tabpanel"]'), this.settings = a.extend({}, d, c), this.init()
        }
        var c = "toggleBSCollapse",
            d = {};
        a.extend(b.prototype, {
            init: function() {
                var a = this;
                this.$elem.on("click", function() {
                    a.$contentContainer.collapse(a.$elem.hasClass("state_all-hidden") ? "show" : "hide"), a.$elem.toggleClass("state_all-hidden")
                }), this.$contentContainer.on("shown.bs.collapse hidden.bs.collapse", function() {
                    var b = a.$contentContainer.filter(".in").length;
                    b === a.$contentContainer.length ? a.$elem.removeClass("state_all-hidden") : a.$elem.addClass("state_all-hidden")
                })
            }
        }), a.fn[c] = function(d) {
            return this.each(function() {
                a.data(this, "plugin_" + c) || a.data(this, "plugin_" + c, new b(this, d))
            })
        }
    }(jQuery), $(function() {
        $(".js_toggle-accordion").toggleBSCollapse()
    }),
    function(a) {
        function b(b) {
            this.$elem = a(b), this.$target = a(this.$elem.data("target")), this.onEvent = this.$elem.data("on"), this.triggerEvent = this.$elem.data("trigger-event"), this.init()
        }
        var c = "elementTrigger";
        a.extend(b.prototype, {
            init: function() {
                var a = this;
                a.$elem.on(a.onEvent, function() {
                    a.$target.trigger(a.triggerEvent)
                })
            }
        }), a.fn[c] = function(d) {
            return this.each(function() {
                a.data(this, "plugin_" + c) || a.data(this, "plugin_" + c, new b(this, d))
            })
        }
    }(jQuery), $(function() {
        $(".js_trigger").elementTrigger()
    }),
    function(a) {
        function b(b) {
            this.$elem = a(b), this.limitPerChannel = this.$elem.data("limit-per-channel") || 4, this.init()
        }
        var c = "socialMediaStream";
        a.extend(b.prototype, {
            init: function() {
                var b = this;
                a.get("http://man-centre.com/templates/russian/js/social-media-stream.js").done(function() {
                    b.$elem.socialfeed({
                        facebook: {
                            accounts: ["@mantruckandbus"],
                            limit: b.limitPerChannel,
                            access_token: "720098404793336|91f7987dc582e05d7c8e876ea7c61d59"
                        },
                        twitter: {
                            accounts: ["@MAN_Group"],
                            limit: b.limitPerChannel,
                            consumer_key: "yzqxBXUqtjI3yn2bM76RydKuu",
                            consumer_secret: "mLLCWapswokDGSoscjGCKgEn1oCcszD7pJF8HiJal2ky2Yh2FI"
                        },
                        media_min_width: 300,
                        show_media: !0,
                        date_format: I18NService.getDateFormat().toUpperCase(),
                        length: 200,
                        template_html: a("#js_tpl-social-media-stream").text(),
                        callback: function() {
                            b.initBabylongrid()
                        }
                    })
                })
            },
            initBabylongrid: function() {
                var a = this;
                a.$elem.babylongrid({
                    scheme: [{
                        minWidth: 960,
                        columns: 3
                    }, {
                        minWidth: 600,
                        columns: 2
                    }, {
                        minWidth: 0,
                        columns: 1
                    }]
                }), a.$elem.find("img").load(function() {
                    a.$elem.trigger("babylongrid:resize")
                }), setTimeout(function() {
                    a.$elem.trigger("babylongrid:resize")
                }, 1500)
            }
        }), a.fn[c] = function() {
            return this.each(function() {
                a.data(this, "plugin_" + c) || a.data(this, "plugin_" + c, new b(this))
            })
        }
    }($), $(function() {
        $("#js_social-media-stream").socialMediaStream()
    }),
    function(a) {
        function b(b) {
            this.$elem = a(b), this.jsonPath = this.$elem.data("json-path"), this.data = JSON.parse(a("#js_question-answer-data").text()), this.questionTpl = a("#js_tpl-question-answer--question").text(), this.answerTpl = a("#js_tpl-question-answer--answer").text(), this.init()
        }
        var c = "questionAnswer";
        a.extend(b.prototype, {
            init: function() {
                this.generateQuestion(this.$elem, this.data), this.thisEventHandler()
            },
            thisEventHandler: function() {
                var b = this;
                a(b.$elem).on("change", "[data-next-step-id]", function() {
                    if(a(this).is(":checked")) {
                        var c = b.getObjByID(a(this).attr("data-next-step-id"), b.data);
                        "undefined" == typeof c.solutionText ? b.generateQuestion(a(this).closest(".js_result"), c) : b.generateAnswer(a(this).closest(".js_result"), c)
                    }
                })
            },
            generateQuestion: function(a, b) {
                var c = this.questionTpl;
                c = c.replace(/\{\{questionId}}/g, b.questionId).replace("{{questionText}}", b.questionText).replace("{{left_text}}", b.left_text).replace(/\{\{left-next-step-id}}/g, b.left.questionId).replace("{{right_text}}", b.right_text).replace(/\{\{right-next-step-id}}/g, b.right.questionId), this.insertHTMLinTarget(a.find(".js_result"), c)
            },
            generateAnswer: function(a, b) {
                var c = this.answerTpl;
                c = c.replace("{{solutionImage}}", b.solutionImage).replace("{{solutionImageTitle}}", b.solutionImageTitle).replace("{{solutionText}}", b.solutionText).replace("{{solutionLink.url}}", b.solutionLink.url).replace("{{solutionLink.target}}", b.solutionLink.target), this.insertHTMLinTarget(a.find(".js_result"), c)
            },
            insertHTMLinTarget: function(a, b) {
                0 === a.children().length ? (a.hide().html(b), a.slideDown()) : a.slideUp(333, function() {
                    a.html(b), a.slideDown()
                })
            },
            getObjByID: function(a, b) {
                var c = this;
                for(var d in b)
                    if(b.hasOwnProperty(d)) {
                        if(b[d] === a) return b;
                        if("object" == typeof b[d]) {
                            var e = c.getObjByID(a, b[d]);
                            if(null !== e) return e
                        }
                    }
                return null
            }
        }), a.fn[c] = function() {
            return this.each(function() {
                a.data(this, "plugin_" + c) || a.data(this, "plugin_" + c, new b(this))
            })
        }
    }(jQuery), $(function() {
        $(".js_question-answer").questionAnswer()
    }),
    function(a) {
        function b() {
            a(".js_sb-prev", f).on("click", function() {
                g.previous()
            }), a(".js_sb-next", f).on("click", function() {
                g.next()
            })
        }

        function c() {
            g = e.slicebox(i), b()
        }

        function d() {
            a.getScript("http://man-centre.com/templates/russian/js/slicebox.js").done(c)
        }
        var e = a("#js_sb-slider");
        if(0 !== e.length) {
            var f = a("#slicebox"),
                g = void 0,
                h = e.data("sb-options") || {},
                i = a.extend({}, {
                    orientation: "r",
                    cuboidsRandom: !0,
                    colorHiddenSides: "#222",
                    speed: 600,
                    easing: "ease",
                    disperseFactor: 30,
                    interval: 3e3,
                    autoplay: !1,
                    fallbackFadeSpeed: 600,
                    $elWrapper: a("#js_slider-container"),
                    onBeforeChange: function() {
                        f.addClass("state_slide-is-running")
                    },
                    onAfterChange: function() {
                        f.removeClass("state_slide-is-running")
                    }
                }, h);
            a(function() {
                d()
            })
        }
    }(jQuery),
    function(a, b) {
        var c = a(".marginal-column > .row");
        a(b).load(function() {
            c.babylongrid({
                scheme: [{
                    minWidth: 1012,
                    columns: 1
                }, {
                    minWidth: 480,
                    columns: 2
                }, {
                    minWidth: 0,
                    columns: 1
                }]
            })
        }), a("iframe, img", c).load(function() {
            setTimeout(function() {
                c.trigger("babylongrid:resize")
            }, 100)
        }), setTimeout(function() {
            c.trigger("babylongrid:resize")
        }, 1500), setTimeout(function() {
            c.trigger("babylongrid:resize")
        }, 2500), a('a[data-toggle="tab"]', c).on("shown.bs.tab", function() {
            c.trigger("babylongrid:resize")
        })
    }($, window), $(function() {
        $("#js_store-locator").length && $.getScript("http://man-centre.com/templates/russian/js/store-locator.js", function() {})
    }), $(function() {
        var a = $("#js_media-stage");
        a.children(".js_slider").slick({
            dots: !1,
            infinite: !0,
            slidesToShow: 3,
            slidesToScroll: 3,
            centerPadding: 0,
            centerMode: !0,
            prevArrow: a.find(".slick-prev"),
            nextArrow: a.find(".slick-next"),
            responsive: [{
                breakpoint: 768,
                settings: {
                    centerPadding: "80px",
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    arrows: !1
                }
            }, {
                breakpoint: 480,
                settings: {
                    centerPadding: "30px",
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    arrows: !1
                }
            }]
        })
    }), $(function() {}), $(function() {
        $(".js_toggle-filter").on("click", function(a) {
            a.stopPropagation(), a.preventDefault();
            var b = $($(this).attr("href"));
            AreaDataService.toggleExpandedAreaState($(this)), AreaDataService.toggleVisibleAreaState(b), $(this).hasClass("icon-plus") && $(this).toggleClass("state_open"), b.slideToggle()
        })
    }),
    function(a) {
        a(function() {
            function b() {
                a(".equalizer").each(function() {
                    var b, c = 0;
                    a("#mediaCenter.pictureList").length > 0 && (b = a(this).find(".statistics .h3").map(function() {
                        return a(this).height()
                    }).get(), c = Math.max.apply(null, b), a(this).find(".statistics .h3").height(c)), b = a(this).find("p.intro").map(function() {
                        return a(this).height()
                    }).get(), c = Math.max.apply(null, b), a(this).find("p.intro").height(c)
                }), e = !0
            }

            function c() {
                a(".equalizer").each(function() {
                    a("#mediaCenter.pictureList").length > 0 && a(this).find(".statistics .h3").height(""), a(this).find("p.intro").height("")
                })
            }
            var d = !1;
            a("#mediaCenter:not(.pictureList)").length && (d ? a("#mediaCenter:not(.pictureList)").mediaCenter() : a.getScript("http://man-centre.com/templates/russian/js/media-center.js").done(function() {
                d = !0, a("#mediaCenter:not(.pictureList)").mediaCenter()
            }));
            var e = !1;
            a(window).width() > 462 && (e ? c() : b()), a(window).resize(function() {
                a(window).width() > 462 && (e ? c() : b())
            })
        })
    }($),
    function(a) {
        a(function() {
            function b() {
                a(".contact-teaser.equalizer").each(function() {
                    var b, c = 0;
                    b = a(this).find("div p.text").map(function() {
                        return a(this).height()
                    }).get(), c = Math.max.apply(null, b), a(this).find("div p.text").height(c)
                }), d = !0
            }

            function c() {
                a(".contact-teaser.equalizer").each(function() {
                    a(this).find("div p.text").height("")
                })
            }
            var d = !1;
            a(".contact-teaser.equalizer a.none").hover(function() {
                a(this).find("picture:not(.hover)").hide(), a(this).find("picture.hover").show()
            }, function() {
                a(this).find("picture:not(.hover)").show(), a(this).find("picture.hover").hide()
            }), Modernizr.touch && a(".equalizer a.none").each(function() {
                a(this).find("picture:not(.hover)").hide(), a(this).find("picture.hover").show()
            }), a(window).width() > 462 && (d ? c() : b()), a(window).resize(function() {
                a(window).width() > 462 && (d ? c() : b())
            })
        })
    }($);