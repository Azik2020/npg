﻿function loadTxt() {

}
function writeTitle() {
    document.write("<title>" + "HTML Editor" + "</title>")
}