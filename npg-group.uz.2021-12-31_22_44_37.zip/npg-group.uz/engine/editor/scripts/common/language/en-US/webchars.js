﻿function loadTxt() {

}
function writeTitle() {
    document.write("<title>" + "Special Characters" + "</title>")
}