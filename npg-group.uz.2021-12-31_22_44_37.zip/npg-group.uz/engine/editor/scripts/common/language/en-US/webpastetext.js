function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Paste text content here (CTRL-V) ";
    document.getElementById("btnCancel").value = "cancel";
    document.getElementById("btnOk").value = " ok ";   
	}
function writeTitle()
	{
	document.write("<title>Paste Text</title>")
	}

