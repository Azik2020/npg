function loadTxt() {
  document.getElementById("lblSource").innerHTML = "URL:";
  document.getElementById("lblWidth").innerHTML = "\u0428\u0438\u0440\u0438\u043d\u0430:";
  document.getElementById("lblHeight").innerHTML = "\u0412\u044b\u0441\u043e\u0442\u0430:";
  document.getElementById("btnCancel").value = "\u041e\u0442\u043c\u0435\u043d\u0430";
  document.getElementById("btnInsert").value = " \u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044c "
}
function writeTitle() {
  document.write("<title>\u0412\u0441\u0442\u0430\u0432\u043a\u0430 \u0444\u043b\u0435\u0448 \u0440\u043e\u043b\u0438\u043a\u0430</title>")
}
;