function loadTxt() {
  document.getElementById("lblUrl").innerHTML = "\u0421\u0441\u044b\u043b\u043a\u0430 \u043d\u0430 \u0430\u0443\u0434\u0438\u043e\u0444\u0430\u0439\u043b (mp3):";
  document.getElementById("btnCancel").value = "\u041e\u0442\u043c\u0435\u043d\u0430";
  document.getElementById("btnLink").value = "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044c"
}
function writeTitle() {
  document.write("<title>" + "\u0412\u0441\u0442\u0430\u0432\u043a\u0430 \u0441\u0441\u044b\u043b\u043a\u0438 \u043d\u0430 \u0430\u0443\u0434\u0438\u043e" + "</title>")
}
;