function loadTxt() {
}
function writeTitle() {
  document.write("<title>" + "\u0418\u0441\u0445\u043e\u0434\u043d\u044b\u0439 HTML \u043a\u043e\u0434" + "</title>")
}
;