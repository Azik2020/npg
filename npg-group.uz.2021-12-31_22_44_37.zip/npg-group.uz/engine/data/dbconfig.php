<?PHP

define ("DBHOST", "localhost");

define ("DBNAME", "man-centre");

define ("DBUSER", "man-centre");

define ("DBPASS", "SAwer56mlp!MC");

define ("PREFIX", "dle");

define ("USERPREFIX", "dle");

define ("COLLATE", "utf8");

define('SECURE_AUTH_KEY', 'u7`RO,MFeM .Ezh 8)m3=8p?}ls*D)?6*^B8.fK|I~5iNgF%niGs9T7xf.7TN*p5');

$db = new db;

?>